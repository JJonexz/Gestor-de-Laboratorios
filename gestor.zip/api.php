<?php
// ============================================================
// api.php — Backend MySQL para Gestor de Laboratorios
// Base de datos: escuela (MariaDB/MySQL)
//
// Tablas propias del gestor (creadas automáticamente):
//   gestor_labs, gestor_profesores, gestor_reservas,
//   gestor_solicitudes, gestor_espera, gestor_pautas
//
// Autenticación: tabla `personal` de la BDD escuela
// ============================================================

// Mostrar errores PHP en la respuesta JSON (debug — quitar en producción)
ini_set('display_errors', 0);
error_reporting(E_ALL);
set_exception_handler(function($e) {
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => $e->getMessage(), 'file' => basename($e->getFile()), 'line' => $e->getLine()], JSON_UNESCAPED_UNICODE);
    exit;
});
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    throw new ErrorException($errstr, $errno, 0, $errfile, $errline);
});

header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

// ── Configuración MySQL ──────────────────────────────────────
// Editá estos valores según tu servidor
define('DB_HOST', 'localhost');
define('DB_NAME', 'escuela');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_PORT', 3306);

// ── Conectar a MySQL ─────────────────────────────────────────
function getDB() {
    static $pdo = null;
    if ($pdo) return $pdo;

    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT
         . ';dbname=' . DB_NAME . ';charset=utf8mb4';

    $pdo = new PDO($dsn, DB_USER, DB_PASS, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4",
    ]);

    // Opcional: Solo inicializar si se solicita explícitamente o en el login
    // Para evitar deadlocks en peticiones concurrentes, no ejecutamos initSchema siempre.
    return $pdo;
}

function initSchema($pdo) {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS gestor_labs (
            id        VARCHAR(10) NOT NULL,
            nombre    VARCHAR(100) NOT NULL,
            ocupado   TINYINT NOT NULL DEFAULT 0,
            capacidad SMALLINT NOT NULL DEFAULT 20,
            notas     VARCHAR(500) NOT NULL DEFAULT '',
            PRIMARY KEY (id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS gestor_profesores (
            id          INT NOT NULL AUTO_INCREMENT,
            apellido    VARCHAR(50) NOT NULL,
            nombre      VARCHAR(50) NOT NULL,
            orientacion VARCHAR(50) NOT NULL DEFAULT 'bas',
            materia     VARCHAR(100) NOT NULL DEFAULT '',
            dni_personal INT DEFAULT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY (dni_personal)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS gestor_reservas (
            id           INT NOT NULL AUTO_INCREMENT,
            semanaOffset INT NOT NULL DEFAULT 0,
            dia          TINYINT NOT NULL,
            modulo       TINYINT NOT NULL,
            lab          VARCHAR(10) NOT NULL,
            curso        VARCHAR(20) NOT NULL,
            orient       VARCHAR(50) NOT NULL DEFAULT 'bas',
            profeId      VARCHAR(50) NOT NULL,
            secuencia    VARCHAR(500) NOT NULL DEFAULT '',
            cicloClases  TINYINT NOT NULL DEFAULT 1,
            renovaciones TINYINT NOT NULL DEFAULT 0,
            anual        TINYINT NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            INDEX idx_slot (lab, dia, modulo, semanaOffset),
            INDEX idx_profe (profeId)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS gestor_solicitudes (
            id                INT NOT NULL AUTO_INCREMENT,
            semanaOffset      INT NOT NULL DEFAULT 0,
            dia               TINYINT NOT NULL,
            modulo            TINYINT NOT NULL,
            lab               VARCHAR(10) NOT NULL,
            curso             VARCHAR(20) NOT NULL,
            orient            VARCHAR(50) NOT NULL DEFAULT 'bas',
            profeId           VARCHAR(50) NOT NULL,
            secuencia         VARCHAR(500) NOT NULL DEFAULT '',
            cicloClases       TINYINT NOT NULL DEFAULT 1,
            estado            VARCHAR(20) NOT NULL DEFAULT 'pendiente',
            esRenovacion      TINYINT NOT NULL DEFAULT 0,
            reservaOriginalId INT DEFAULT NULL,
            renovacionNum     TINYINT NOT NULL DEFAULT 0,
            PRIMARY KEY (id),
            INDEX idx_estado (estado)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS gestor_espera (
            id           INT NOT NULL AUTO_INCREMENT,
            profeId      VARCHAR(50) NOT NULL,
            lab          VARCHAR(10) NOT NULL,
            dia          TINYINT NOT NULL,
            modulo       TINYINT NOT NULL,
            semanaOffset INT NOT NULL DEFAULT 0,
            PRIMARY KEY (id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

        CREATE TABLE IF NOT EXISTS gestor_pautas (
            id    INT NOT NULL AUTO_INCREMENT,
            texto TEXT NOT NULL,
            PRIMARY KEY (id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    // ── Migraciones seguras: añadir columnas nuevas si no existen ──
    // max_grupos en gestor_labs (soporta múltiples grupos por slot)
    if (!$pdo->query("SHOW COLUMNS FROM gestor_labs LIKE 'max_grupos'")->fetch()) {
        $pdo->exec("ALTER TABLE gestor_labs ADD COLUMN max_grupos TINYINT NOT NULL DEFAULT 1");
    }
    // grupoId en gestor_reservas (referencia a tabla grupos de la BD escuela)
    if (!$pdo->query("SHOW COLUMNS FROM gestor_reservas LIKE 'grupoId'")->fetch()) {
        $pdo->exec("ALTER TABLE gestor_reservas ADD COLUMN grupoId INT DEFAULT NULL");
    }
    // cupofId en gestor_reservas y gestor_solicitudes (referencia a tabla cupof)
    if (!$pdo->query("SHOW COLUMNS FROM gestor_reservas LIKE 'cupofId'")->fetch()) {
        $pdo->exec("ALTER TABLE gestor_reservas ADD COLUMN cupofId INT DEFAULT NULL");
    }
    if (!$pdo->query("SHOW COLUMNS FROM gestor_solicitudes LIKE 'cupofId'")->fetch()) {
        $pdo->exec("ALTER TABLE gestor_solicitudes ADD COLUMN cupofId INT DEFAULT NULL");
    }
    // grupoId en gestor_solicitudes (misma referencia para solicitudes pendientes)
    if (!$pdo->query("SHOW COLUMNS FROM gestor_solicitudes LIKE 'grupoId'")->fetch()) {
        $pdo->exec("ALTER TABLE gestor_solicitudes ADD COLUMN grupoId INT DEFAULT NULL");
    }
    
    // Migración: cambiar profeId de INT a VARCHAR para soportar 'institucional'
    $reservasProfeCheck = $pdo->query("SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='gestor_reservas' AND COLUMN_NAME='profeId' AND TABLE_SCHEMA=DATABASE()")->fetch();
    if ($reservasProfeCheck && stripos($reservasProfeCheck['COLUMN_TYPE'], 'INT') !== false) {
        $pdo->exec("ALTER TABLE gestor_reservas MODIFY COLUMN profeId VARCHAR(50) NOT NULL");
    }
    $solicProfeCheck = $pdo->query("SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='gestor_solicitudes' AND COLUMN_NAME='profeId' AND TABLE_SCHEMA=DATABASE()")->fetch();
    if ($solicProfeCheck && stripos($solicProfeCheck['COLUMN_TYPE'], 'INT') !== false) {
        $pdo->exec("ALTER TABLE gestor_solicitudes MODIFY COLUMN profeId VARCHAR(50) NOT NULL");
    }
    $esperaProfeCheck = $pdo->query("SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME='gestor_espera' AND COLUMN_NAME='profeId' AND TABLE_SCHEMA=DATABASE()")->fetch();
    if ($esperaProfeCheck && stripos($esperaProfeCheck['COLUMN_TYPE'], 'INT') !== false) {
        $pdo->exec("ALTER TABLE gestor_espera MODIFY COLUMN profeId VARCHAR(50) NOT NULL");
    }

    syncFromMaster($pdo);
}

function syncFromMaster($pdo) {
    // 1. Sincronizar SALONES -> GESTOR_LABS
    $hasSalones = $pdo->query("SHOW TABLES LIKE 'salones'")->fetch();
    if ($hasSalones) {
        // Limpiar labs de ejemplo (A,B,C) SOLO si la tabla gestor_labs está vacía
        // (primer arranque). Nunca borrar si ya hay datos reales cargados.
        $cntLabs = (int)$pdo->query("SELECT COUNT(*) FROM gestor_labs")->fetchColumn();
        if ($cntLabs === 0) {
            $pdo->exec("DELETE FROM gestor_labs WHERE id IN ('A', 'B', 'C')");
            // Solo borramos reservas/solicitudes fantasma en primer arranque
            $pdo->exec("DELETE FROM gestor_reservas WHERE lab IN ('A', 'B', 'C')");
            $pdo->exec("DELETE FROM gestor_solicitudes WHERE lab IN ('A', 'B', 'C')");
        }

        // INSERT nuevos salones + UPDATE nombre/capacidad/notas de existentes.
        // NO toca el campo 'ocupado' (lo gestiona el gestor manualmente).
        // CAST asegura id siempre VARCHAR, consistente con gestor_reservas.lab
        $pdo->exec("
            INSERT INTO gestor_labs (id, nombre, capacidad, notas)
            SELECT 
                CAST(id_salones AS CHAR),
                CONCAT(tipo, ' ', numero),
                capacidad,
                CONCAT('Ubicación: ', ubicacion)
            FROM salones
            ON DUPLICATE KEY UPDATE
                nombre    = VALUES(nombre),
                capacidad = VALUES(capacidad),
                notas     = VALUES(notas)
        ");
    }

    // 2. Sincronizar PERSONAL -> GESTOR_PROFESORES
    $hasPersonal = $pdo->query("SHOW TABLES LIKE 'personal'")->fetch();
    if ($hasPersonal) {
        // Solo eliminamos profesores sin DNI vinculado si no tienen reservas asociadas
        $pdo->exec("
            DELETE FROM gestor_profesores
            WHERE dni_personal IS NULL
              AND id NOT IN (SELECT DISTINCT profeId FROM gestor_reservas)
              AND id NOT IN (SELECT DISTINCT profeId FROM gestor_solicitudes)
        ");

        $pdo->exec("
            INSERT INTO gestor_profesores (apellido, nombre, dni_personal, materia)
            SELECT apellido, nombre, dni, 'Docente'
            FROM personal
            WHERE dni > 0 AND apellido <> ''
            ON DUPLICATE KEY UPDATE
                apellido = VALUES(apellido),
                nombre   = VALUES(nombre)
        ");
    }
}


// ── Helpers ──────────────────────────────────────────────────
function ok($data)  { echo json_encode(['ok'=>true,'data'=>$data], JSON_UNESCAPED_UNICODE); exit; }
function err($msg, $code=400) { http_response_code($code); echo json_encode(['ok'=>false,'error'=>$msg], JSON_UNESCAPED_UNICODE); exit; }
function body() { return json_decode(file_get_contents('php://input'), true) ?? []; }

function castRow($r) {
    // Los rows de gestor_labs tienen el campo 'ocupado' — lo usamos para detectarlos
    // y forzar su id a string, igual que r.lab en reservas (ambos deben ser string en JS)
    $isLabRow = array_key_exists('ocupado', $r);
    foreach($r as $key => $v) {
        if (is_null($v)) {
            $r[$key] = null;
            continue;
        }
        // Forzar string en: campo 'lab' (referencia en reservas/solicitudes),
        //                    campo 'id' de filas gestor_labs (para que === funcione en JS),
        //                    campo 'id' no numérico (ej: labs legacy 'A','B','C')
        if ($key === 'lab' || ($key === 'id' && (!is_numeric($v) || $isLabRow))) {
            $r[$key] = (string)$v;
            continue;
        }
        if (is_numeric($v) && strpos((string)$v, '.') === false && strlen((string)$v) < 10) {
            $r[$key] = (int)$v;
        } else {
            $r[$key] = $v;
        }
    }
    return $r;
}
function castRows($rows) { return array_map('castRow', $rows); }

// ── Validación de conflictos horarios ─────────────────────────
// Obtiene horarios académicos de un profesor (de tabla cupof + horarios)
function getHorariosAcademicos($pdo, $dniPersonal, $diaLiteral) {
    // diaLiteral: 'LUN', 'MAR', 'MIE', 'JUE', 'VIE'
    // Retorna array de id_horas académicos (1-13)
    if (!$dniPersonal) return [];
    
    $s = $pdo->prepare("
        SELECT DISTINCT h.id_horas
        FROM horarios h
        JOIN cupof c ON h.cupof = c.cupof
        WHERE c.id_materias IS NOT NULL AND h.dia = ?
          AND c.cupof IN (
            SELECT cupof FROM cupof WHERE id_materias IS NOT NULL
          )
    ");
    // Pero necesitamos vincular con el profesor... El problema es que cupof no tiene dni
    // Usamos tabla personal para obtener los cupof del profesor
    $s = $pdo->prepare("
        SELECT DISTINCT h.id_horas
        FROM horarios h
        WHERE h.dia = ? AND h.cupof IN (
            SELECT cupof FROM cupof 
            WHERE id_materias IS NOT NULL
              AND cupof IN (
                SELECT c.cupof FROM cupof c
                WHERE EXISTS (
                  SELECT 1 FROM personal p 
                  WHERE p.dni = ? 
                )
              )
        )
    ");
    // En realidad, cupof no tiene dni_personal. Usamos que varios cupof pueden ser del mismo profe
    // Por ahora, hacemos una búsqueda simple: todos los cupof que coincidan con la estructura
    // Esto es aproximado porque cupof no vincula directamente a personal
    return [];
}

// ── Router ───────────────────────────────────────────────────
$method   = $_SERVER['REQUEST_METHOD'];
$path     = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
$path     = preg_replace('#^.*?api\.php/?#', '', $path);
$segments = array_values(array_filter(explode('/', $path)));
$resource = $segments[0] ?? '';
$id       = $segments[1] ?? null;
$action   = $segments[2] ?? null;

try { $db = getDB(); }
catch (Exception $e) { err('No se pudo conectar a la base de datos MySQL: ' . $e->getMessage(), 500); }

switch ($resource) {

    // ── AUTH / LOGIN ──────────────────────────────────────────
    case 'auth':
    case 'login':
        initSchema($db); // Inicializar/Sincronizar solo al loguear
        if ($method !== 'POST') err('Method not allowed', 405);
        $b        = body();
        $username = strtolower(trim($b['username'] ?? ''));
        $password = $b['password'] ?? '';

        // Administrador estático
        if ($username === 'admin' && $password === 'admin123') {
            ok(['id'=>0,'display'=>'Administrador','role'=>'admin','profeId'=>null,'tag'=>'admin']);
        }

        // DNI numérico
        $row = null;
        if (is_numeric($username)) {
            $s = $db->prepare("SELECT * FROM personal WHERE dni=? LIMIT 1");
            $s->execute([(int)$username]);
            $row = $s->fetch() ?: null;
        }

        // Por tag (número SAEP)
        if (!$row) {
            $s = $db->prepare("SELECT * FROM personal WHERE tag=? AND tag<>'' LIMIT 1");
            $s->execute([$username]);
            $row = $s->fetch() ?: null;
        }

        // Por apellido.primerNombre  (ej: "ces.leandro")
        if (!$row) {
            $s = $db->prepare(
                "SELECT * FROM personal
                 WHERE LOWER(CONCAT(
                     REPLACE(LOWER(TRIM(apellido)), ' ', ''),
                     '.',
                     LOWER(SUBSTRING_INDEX(TRIM(nombre), ' ', 1))
                 )) = ? LIMIT 1"
            );
            $s->execute([$username]);
            $row = $s->fetch() ?: null;
        }

        // Por apellido solo (ej: "ces")
        if (!$row) {
            $s = $db->prepare(
                "SELECT * FROM personal WHERE LOWER(REPLACE(TRIM(apellido),' ',''))=? LIMIT 1"
            );
            $s->execute([str_replace(' ', '', $username)]);
            $row = $s->fetch() ?: null;
        }

        if (!$row) err('Usuario no encontrado', 401);
        if ($row['pass'] !== $password) err('Contraseña incorrecta', 401);

        // Buscar profeId en el gestor
        $s2 = $db->prepare("SELECT id FROM gestor_profesores WHERE dni_personal=? LIMIT 1");
        $s2->execute([(int)$row['dni']]);
        $profId = $s2->fetchColumn() ?: null;
        if (!$profId) {
            $s3 = $db->prepare("SELECT id FROM gestor_profesores WHERE UPPER(TRIM(apellido))=UPPER(TRIM(?)) LIMIT 1");
            $s3->execute([$row['apellido']]);
            $profId = $s3->fetchColumn() ?: null;
        }

        $display = ucwords(strtolower(trim($row['apellido'])));
        $computedRole = (isset($row['tag']) && !empty(trim($row['tag']))) ? 'admin' : 'prof';
        ok([
            'id'      => (int)$row['dni'],
            'display' => ($computedRole === 'admin' ? '' : 'Prof. ') . $display,
            'role'    => $computedRole,
            'profeId' => $profId ? (int)$profId : null,
            'tag'     => $row['tag'] ?? '',
        ]);

    // ── PERSONAL (búsqueda de docentes) ──────────────────────
    case 'personal':
        if ($method !== 'GET') err('Method not allowed', 405);
        $q = trim($_GET['q'] ?? '');
        if (strlen($q) < 2) ok([]);
        $s = $db->prepare(
            "SELECT dni,apellido,nombre,email,tag FROM personal
             WHERE apellido LIKE ? OR nombre LIKE ?
             ORDER BY apellido,nombre LIMIT 20"
        );
        $s->execute(["%$q%", "%$q%"]);
        ok(castRows($s->fetchAll()));

    // ── LABS ──────────────────────────────────────────────────
    case 'labs':
        if ($method === 'GET') ok(castRows($db->query('SELECT * FROM gestor_labs ORDER BY id')->fetchAll()));
        if ($method === 'POST') {
            $b = body();
            $db->prepare('INSERT INTO gestor_labs(id,nombre,ocupado,capacidad,notas,max_grupos) VALUES(?,?,?,?,?,?)')
               ->execute([$b['id'],$b['nombre'],(int)($b['ocupado']??0),(int)($b['capacidad']??20),$b['notas']??'',(int)($b['max_grupos']??1)]);
            $s=$db->prepare('SELECT * FROM gestor_labs WHERE id=?'); $s->execute([$b['id']]); ok(castRows([$s->fetch()])[0]);
        }
        if ($method === 'PUT' && $id) {
            $b = body();
            $db->prepare('UPDATE gestor_labs SET nombre=?,ocupado=?,capacidad=?,notas=?,max_grupos=? WHERE id=?')
               ->execute([$b['nombre'],(int)($b['ocupado']??0),(int)($b['capacidad']??20),$b['notas']??'',(int)($b['max_grupos']??1),$id]);
            $s=$db->prepare('SELECT * FROM gestor_labs WHERE id=?'); $s->execute([$id]); ok(castRows([$s->fetch()])[0]);
        }
        if ($method === 'DELETE' && $id) {
            $db->prepare('DELETE FROM gestor_labs WHERE id=?')->execute([$id]); ok(['deleted'=>$id]);
        }
        err('Not found',404);

    // ── PROFESORES ────────────────────────────────────────────
    case 'profesores':
        if ($method === 'GET') {
            $repeat = isset($_GET['repeat']) ? max(1, (int)$_GET['repeat']) : 1;
            $data = castRows($db->query('SELECT id,apellido,nombre,orientacion,materia,dni_personal FROM gestor_profesores ORDER BY apellido')->fetchAll());
            if ($repeat > 1) {
                $expanded = [];
                for ($i=0; $i<$repeat; $i++) $expanded = array_merge($expanded, $data);
                $data = $expanded;
            }
            ok($data);
        }
        if ($method === 'POST') {
            $b = body();
            $db->prepare('INSERT INTO gestor_profesores(apellido,nombre,orientacion,materia,dni_personal) VALUES(?,?,?,?,?)')
               ->execute([$b['apellido'],$b['nombre'],$b['orientacion']??'bas',$b['materia']??'',
                          isset($b['dni_personal'])?(int)$b['dni_personal']:null]);
            $newId=(int)$db->lastInsertId();
            $s=$db->prepare('SELECT * FROM gestor_profesores WHERE id=?'); $s->execute([$newId]); ok(castRow($s->fetch()));
        }
        if ($method === 'PUT' && $id) {
            $b = body();
            $db->prepare('UPDATE gestor_profesores SET apellido=?,nombre=?,orientacion=?,materia=?,dni_personal=? WHERE id=?')
               ->execute([$b['apellido'],$b['nombre'],$b['orientacion']??'bas',$b['materia']??'',
                          isset($b['dni_personal'])?(int)$b['dni_personal']:null,(int)$id]);
            $s=$db->prepare('SELECT * FROM gestor_profesores WHERE id=?'); $s->execute([(int)$id]); ok(castRow($s->fetch()));
        }
        if ($method === 'DELETE' && $id) {
            $db->prepare('DELETE FROM gestor_profesores WHERE id=?')->execute([(int)$id]); ok(['deleted'=>(int)$id]);
        }
        err('Not found',404);

    // ── RESERVAS ──────────────────────────────────────────────
    case 'reservas':
        if ($method === 'GET') {
            $where='1=1'; $p=[];
            if (isset($_GET['semanaOffset'])) { $where.=' AND semanaOffset=?'; $p[]=(int)$_GET['semanaOffset']; }
            if (isset($_GET['profeId'])) { 
                // Soportar búsqueda tanto de IDs númericos como de 'institucional'
                $where.=' AND profeId=?'; 
                $p[]=($_GET['profeId'] === 'institucional') ? 'institucional' : $_GET['profeId'];
            }
            $s=$db->prepare("SELECT * FROM gestor_reservas WHERE $where ORDER BY semanaOffset,dia,modulo");
            $s->execute($p); ok(castRows($s->fetchAll()));
        }
        if ($method === 'POST') {
            $b=body();
            $grupoId = isset($b['grupoId']) && $b['grupoId'] !== null ? (int)$b['grupoId'] : null;

            // --- VALIDACIÓN BÁSICA ---
            // Validar que profeId exista (si no es 'institucional')
            if (isset($b['profeId']) && $b['profeId'] !== 'institucional') {
                $checkProfe = $db->prepare('SELECT id FROM gestor_profesores WHERE id=?');
                $checkProfe->execute([(int)$b['profeId']]);
                if (!$checkProfe->fetch()) {
                    err('El docente no existe', 400);
                }
            }
            
            // Validar que lab exista
            $checkLab = $db->prepare('SELECT id FROM gestor_labs WHERE id=?');
            $checkLab->execute([$b['lab']]);
            if (!$checkLab->fetch()) {
                err('El laboratorio no existe', 400);
            }
            
            // Validar rango de módulo y día
            $modulo = (int)$b['modulo'];
            $dia = (int)$b['dia'];
            if ($modulo < 0 || $modulo > 15) err('Módulo inválido (0-15)', 400);
            if ($dia < 0 || $dia > 4) err('Día inválido (0-4)', 400);

            // --- VALIDACIÓN DE LÍMITE DE GRUPOS ---
            // Límite de grupos manejado exclusivamente por el frontend (LABS_CONFIG)
            // La validación de conflictos horarios se hace en el frontend
            // (requeriría JOIN complejo con tabla cupof que no tiene dni_personal)
            // -----------------------------------------------------------------------

            // Preparar profeId: si es 'institucional' dejarlo como string, si no convertir a int
            $profeIdVal = ($b['profeId'] === 'institucional') ? 'institucional' : (int)$b['profeId'];

            $cupofId = isset($b['cupofId']) && $b['cupofId'] !== null ? (int)$b['cupofId'] : null;
            $db->prepare('INSERT INTO gestor_reservas(semanaOffset,dia,modulo,lab,curso,orient,profeId,secuencia,cicloClases,renovaciones,anual,grupoId,cupofId) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)')
               ->execute([(int)($b['semanaOffset']??0),$dia,$modulo,
                           $b['lab'],$b['curso'],$b['orient']??'bas',$profeIdVal,
                           $b['secuencia']??'',(int)($b['cicloClases']??1),
                           (int)($b['renovaciones']??0),(int)($b['anual']??0),$grupoId,$cupofId]);
            $newId=(int)$db->lastInsertId();
            $s=$db->prepare('SELECT * FROM gestor_reservas WHERE id=?'); $s->execute([$newId]); ok(castRow($s->fetch()));
        }
        if ($method === 'PUT' && $id) {
            $b=body();
            $grupoId = isset($b['grupoId']) && $b['grupoId'] !== null ? (int)$b['grupoId'] : null;
            // Preparar profeId: si es 'institucional' dejarlo como string, si no convertir a int
            $profeIdVal = ($b['profeId'] === 'institucional') ? 'institucional' : (int)$b['profeId'];
            $cupofId = isset($b['cupofId']) && $b['cupofId'] !== null ? (int)$b['cupofId'] : null;
            $db->prepare('UPDATE gestor_reservas SET semanaOffset=?,dia=?,modulo=?,lab=?,curso=?,orient=?,profeId=?,secuencia=?,cicloClases=?,renovaciones=?,anual=?,grupoId=?,cupofId=? WHERE id=?')
               ->execute([(int)($b['semanaOffset']??0),(int)$b['dia'],(int)$b['modulo'],
                           $b['lab'],$b['curso'],$b['orient']??'bas',$profeIdVal,
                           $b['secuencia']??'',(int)($b['cicloClases']??1),
                           (int)($b['renovaciones']??0),(int)($b['anual']??0),$grupoId,$cupofId,(int)$id]);
            $s=$db->prepare('SELECT * FROM gestor_reservas WHERE id=?'); $s->execute([(int)$id]); ok(castRow($s->fetch()));
        }
        if ($method === 'DELETE' && $id) {
            if ($action === 'serie') {
                $b=body();
                $db->prepare('DELETE FROM gestor_reservas WHERE lab=? AND dia=? AND profeId=? AND curso=? AND anual=1')
                   ->execute([$b['lab'],(int)$b['dia'],(int)$b['profeId'],$b['curso']]);
                ok(['deleted_series'=>true]);
            }
            $db->prepare('DELETE FROM gestor_reservas WHERE id=?')->execute([(int)$id]); ok(['deleted'=>(int)$id]);
        }
        err('Not found',404);

    // ── SOLICITUDES ───────────────────────────────────────────
    case 'solicitudes':
        if ($method === 'GET') {
            $where='1=1'; $p=[];
            if (isset($_GET['estado']))  { $where.=' AND estado=?';  $p[]=$_GET['estado']; }
            if (isset($_GET['profeId'])) { 
                // Soportar búsqueda tanto de IDs numéricos como de 'institucional'
                $where.=' AND profeId=?'; 
                $p[]=($_GET['profeId'] === 'institucional') ? 'institucional' : $_GET['profeId'];
            }
            $s=$db->prepare("SELECT * FROM gestor_solicitudes WHERE $where ORDER BY id");
            $s->execute($p); ok(castRows($s->fetchAll()));
        }
        if ($method === 'POST') {
            $b=body();
            $grupoId = isset($b['grupoId']) && $b['grupoId'] !== null ? (int)$b['grupoId'] : null;
            
            // Preparar profeId: si es 'institucional' dejarlo como string, si no convertir a int
            $profeIdVal = ($b['profeId'] === 'institucional') ? 'institucional' : (int)$b['profeId'];
            
            $db->prepare('INSERT INTO gestor_solicitudes(semanaOffset,dia,modulo,lab,curso,orient,profeId,secuencia,cicloClases,estado,esRenovacion,reservaOriginalId,renovacionNum,grupoId,cupofId) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
               ->execute([(int)($b['semanaOffset']??0),(int)$b['dia'],(int)$b['modulo'],
                           $b['lab'],$b['curso'],$b['orient']??'bas',$profeIdVal,
                           $b['secuencia']??'',(int)($b['cicloClases']??1),
                           $b['estado']??'pendiente',(int)($b['esRenovacion']??0),
                           isset($b['reservaOriginalId'])?(int)$b['reservaOriginalId']:null,
                           (int)($b['renovacionNum']??0),$grupoId,
                           isset($b['cupofId']) && $b['cupofId'] !== null ? (int)$b['cupofId'] : null]);
            $newId=(int)$db->lastInsertId();
            $s=$db->prepare('SELECT * FROM gestor_solicitudes WHERE id=?'); $s->execute([$newId]); ok(castRow($s->fetch()));
        }
        if ($method === 'PUT' && $id) {
            $b=body(); $fields=[]; $vals=[];
            foreach(['semanaOffset','dia','modulo','lab','curso','orient','profeId',
                     'secuencia','cicloClases','estado','esRenovacion','reservaOriginalId','renovacionNum'] as $f) {
                if (array_key_exists($f,$b)) { $fields[]="$f=?"; $vals[]=$b[$f]; }
            }
            if ($fields) { $vals[]=(int)$id; $db->prepare('UPDATE gestor_solicitudes SET '.implode(',',$fields).' WHERE id=?')->execute($vals); }
            $s=$db->prepare('SELECT * FROM gestor_solicitudes WHERE id=?'); $s->execute([(int)$id]); ok(castRow($s->fetch()));
        }
        if ($method === 'DELETE' && $id) {
            $db->prepare('DELETE FROM gestor_solicitudes WHERE id=?')->execute([(int)$id]); ok(['deleted'=>(int)$id]);
        }
        err('Not found',404);

    // ── ESPERA ────────────────────────────────────────────────
    case 'espera':
        if ($method === 'GET') ok(castRows($db->query('SELECT * FROM gestor_espera ORDER BY id')->fetchAll()));
        if ($method === 'POST') {
            $b=body();
            $db->prepare('INSERT INTO gestor_espera(profeId,lab,dia,modulo,semanaOffset) VALUES(?,?,?,?,?)')
               ->execute([(int)$b['profeId'],$b['lab'],(int)$b['dia'],(int)$b['modulo'],(int)($b['semanaOffset']??0)]);
            $newId=(int)$db->lastInsertId();
            ok(['id'=>$newId,'profeId'=>(int)$b['profeId'],'lab'=>$b['lab'],
                'dia'=>(int)$b['dia'],'modulo'=>(int)$b['modulo'],'semanaOffset'=>(int)($b['semanaOffset']??0)]);
        }
        if ($method === 'DELETE' && $id) {
            $db->prepare('DELETE FROM gestor_espera WHERE id=?')->execute([(int)$id]); ok(['deleted'=>(int)$id]);
        }
        err('Not found',404);

    // ── PAUTAS ────────────────────────────────────────────────
    case 'pautas':
        if ($method === 'GET') {
            $rows=$db->query('SELECT * FROM gestor_pautas ORDER BY id')->fetchAll();
            ok(array_map(fn($r)=>['id'=>(int)$r['id'],'texto'=>$r['texto']],$rows));
        }
        if ($method === 'POST') {
            $b=body();
            $db->prepare('INSERT INTO gestor_pautas(texto) VALUES(?)')->execute([$b['texto']]);
            ok(['id'=>(int)$db->lastInsertId(),'texto'=>$b['texto']]);
        }
        if ($method === 'DELETE' && $id) {
            $db->prepare('DELETE FROM gestor_pautas WHERE id=?')->execute([(int)$id]); ok(['deleted'=>(int)$id]);
        }
        err('Not found',404);

    // ── CURSOS ────────────────────────────────────────────────
    case 'grupos':
        if ($method !== 'GET') err('Method not allowed', 405);
        $hasGrupos = $db->query("SHOW TABLES LIKE 'grupos'")->fetch();
        if (!$hasGrupos) ok([]);
        ok(castRows($db->query('SELECT id, nombre, id_cursos FROM grupos ORDER BY id_cursos, nombre')->fetchAll()));

    case 'cursos':
        if ($method !== 'GET') err('Method not allowed', 405);
        ok(castRows($db->query('SELECT id, division, ano, turno FROM cursos ORDER BY ano, division')->fetchAll()));

    // ── MATERIAS ──────────────────────────────────────────────
    case 'materias':
        if ($method !== 'GET') err('Method not allowed', 405);
        ok(castRows($db->query('SELECT id, nombre, abreviatura FROM materias ORDER BY nombre')->fetchAll()));

    // ── HORARIOS ACADÉMICOS (cupof + horarios vinculado a personal via revista) ─
    case 'horarios-academicos':
        if ($method !== 'GET') err('Method not allowed', 405);
        $dni_personal = isset($_GET['dni']) ? (int)$_GET['dni'] : null;
        if (!$dni_personal) ok([]);

        // Vinculación real: personal → revista → cupof → horarios + materias + cursos
        $s = $db->prepare("
            SELECT DISTINCT
                h.dia,
                h.id_horas,
                c.cupof,
                c.id_cursos,
                c.id_materias,
                m.nombre  AS materia_nombre,
                m.abreviatura AS materia_abrev,
                cu.ano         AS curso_ano,
                cu.division    AS curso_division,
                c.turno        AS cupof_turno
            FROM revista r
            JOIN cupof    c  ON r.cupof       = c.cupof
            JOIN horarios h  ON h.cupof        = c.cupof
            LEFT JOIN materias m  ON c.id_materias = m.id
            LEFT JOIN cursos   cu ON c.id_cursos   = cu.id
            WHERE r.dni_personal = ?
              AND (r.fh IS NULL OR YEAR(r.fh) = 0 OR r.fh >= CURDATE())
            ORDER BY h.dia, h.id_horas
        ");
        $s->execute([$dni_personal]);
        ok(castRows($s->fetchAll()));

    // ── CUPOFS POR PROFE (materias y cursos del docente para el modal de reserva) ─
    case 'cupofs-por-profe':
        if ($method !== 'GET') err('Method not allowed', 405);
        $dni_personal = isset($_GET['dni']) ? (int)$_GET['dni'] : null;
        if (!$dni_personal) ok([]);

        // Devuelve los cupofs activos del profesor con materia + curso + turno
        // fh = '0000-00-00' significa sin fecha de baja (cargo activo)
        // Cubrimos: NULL, '0000-00-00' (string), fecha futura, o fecha en blanco
        $s = $db->prepare("
            SELECT DISTINCT
                c.cupof,
                c.id_materias,
                c.id_cursos,
                c.turno        AS cupof_turno,
                c.hsmodcar,
                c.id_grupos,
                m.nombre       AS materia_nombre,
                m.abreviatura  AS materia_abrev,
                cu.ano         AS curso_ano,
                cu.division    AS curso_division,
                CONCAT(cu.ano, '°', cu.division,
                    IF(cu.turno IS NOT NULL AND cu.turno <> '',
                        CONCAT(' (', cu.turno, ')'), '')
                ) AS curso_label,
                g.nombre       AS grupo_nombre
            FROM revista r
            JOIN cupof    c  ON r.cupof       = c.cupof
            LEFT JOIN materias m  ON c.id_materias = m.id
            LEFT JOIN cursos   cu ON c.id_cursos   = cu.id
            LEFT JOIN grupos   g  ON c.id_grupos   = g.id AND c.id_grupos > 0
            WHERE r.dni_personal = ?
              AND (r.fh IS NULL OR YEAR(r.fh) = 0 OR r.fh >= CURDATE())
            ORDER BY cu.ano, cu.division, m.nombre
        ");
        $s->execute([$dni_personal]);
        $rows = $s->fetchAll();
        // Si no hay resultados con el filtro de fecha, intentar sin filtro (fallback)
        if (empty($rows)) {
            $s2 = $db->prepare("
                SELECT DISTINCT
                    c.cupof,
                    c.id_materias,
                    c.id_cursos,
                    c.turno        AS cupof_turno,
                    c.hsmodcar,
                    c.id_grupos,
                    m.nombre       AS materia_nombre,
                    m.abreviatura  AS materia_abrev,
                    cu.ano         AS curso_ano,
                    cu.division    AS curso_division,
                    CONCAT(cu.ano, '°', cu.division,
                        IF(cu.turno IS NOT NULL AND cu.turno <> '',
                            CONCAT(' (', cu.turno, ')'), '')
                    ) AS curso_label,
                    g.nombre       AS grupo_nombre
                FROM revista r
                JOIN cupof    c  ON r.cupof = c.cupof
                LEFT JOIN materias m  ON c.id_materias = m.id
                LEFT JOIN cursos   cu ON c.id_cursos   = cu.id
                LEFT JOIN grupos   g  ON c.id_grupos   = g.id AND c.id_grupos > 0
                WHERE r.dni_personal = ?
                ORDER BY cu.ano, cu.division, m.nombre
            ");
            $s2->execute([$dni_personal]);
            $rows = $s2->fetchAll();
        }
        ok(castRows($rows));

    // ── DEBUG: ver revista de un profe (solo GET, usar con ?dni=X) ──
    case 'debug-revista':
        if ($method !== 'GET') err('Method not allowed', 405);
        $dni = isset($_GET['dni']) ? (int)$_GET['dni'] : null;
        if (!$dni) err('Falta ?dni=', 400);
        $r1 = castRows($db->query("SELECT id, cupof, fd, YEAR(fh) AS fh_year, dni_personal FROM revista WHERE dni_personal=$dni LIMIT 20")->fetchAll());
        $r2 = castRows($db->query("SELECT cupof, id_materias, id_cursos, turno, funcion FROM cupof WHERE cupof IN (SELECT cupof FROM revista WHERE dni_personal=$dni) LIMIT 20")->fetchAll());
        ok(['revista' => $r1, 'cupofs' => $r2, 'dni_buscado' => $dni]);

    // ── HORARIOS FIJOS (Drag & Drop) ──────────────────────────
    case 'horarios_fijos':
        if ($method === 'PUT' && $id) {
            $b = body();
            if (!isset($b['dia'], $b['id_horas'], $b['id_salones'])) {
                err('Faltan datos requeridos: dia, id_horas, id_salones', 400);
            }
            $db->prepare('UPDATE horarios SET dia=?, id_horas=?, id_salones=? WHERE id=?')
               ->execute([$b['dia'], (int)$b['id_horas'], (int)$b['id_salones'], (int)$id]);
            ok(['updated'=>(int)$id]);
        }
        if ($method === 'DELETE' && $id) {
            $db->prepare('DELETE FROM horarios WHERE id=?')->execute([(int)$id]);
            ok(['deleted'=>(int)$id]);
        }
        err('Not found',404);

    // ── ALL ───────────────────────────────────────────────────
    case 'all':
        if ($method !== 'GET') err('Method not allowed', 405);
        $repeat = isset($_GET['repeat']) ? max(1, (int)$_GET['repeat']) : 1;
        $profs = castRows($db->query('SELECT id,apellido,nombre,orientacion,materia,dni_personal FROM gestor_profesores ORDER BY apellido')->fetchAll());
        if ($repeat > 1) {
            $expanded = [];
            for ($i=0; $i<$repeat; $i++) $expanded = array_merge($expanded, $profs);
            $profs = $expanded;
        }

        $res = [
            'labs'        => castRows($db->query('SELECT * FROM gestor_labs ORDER BY id')->fetchAll()),
            'profesores'  => $profs,
            'reservas'    => castRows($db->query('SELECT * FROM gestor_reservas ORDER BY semanaOffset,dia,modulo')->fetchAll()),
            'solicitudes' => castRows($db->query('SELECT * FROM gestor_solicitudes ORDER BY id')->fetchAll()),
            'espera'      => castRows($db->query('SELECT * FROM gestor_espera ORDER BY id')->fetchAll()),
            'pautas'      => castRows($db->query('SELECT * FROM gestor_pautas ORDER BY id')->fetchAll()),
        ];
        
        // Tablas maestras opcionales
        $hasCursos = $db->query("SHOW TABLES LIKE 'cursos'")->fetch();
        if ($hasCursos) $res['cursos'] = castRows($db->query('SELECT id, division, ano, turno FROM cursos ORDER BY ano, division')->fetchAll());

        $hasMaterias = $db->query("SHOW TABLES LIKE 'materias'")->fetch();
        if ($hasMaterias) $res['materias'] = castRows($db->query('SELECT id, nombre, abreviatura FROM materias ORDER BY nombre')->fetchAll());

        $hasGrupos = $db->query("SHOW TABLES LIKE 'grupos'")->fetch();
        if ($hasGrupos) $res['grupos'] = castRows($db->query('SELECT id, nombre, id_cursos FROM grupos ORDER BY id_cursos, nombre')->fetchAll());

        // —— HORARIOS FIJOS (cupof + horarios + salones + materias + cursos) ——
        $hasHorarios = $db->query("SHOW TABLES LIKE 'horarios'")->fetch();
        $hasCupof    = $db->query("SHOW TABLES LIKE 'cupof'")->fetch();
        if ($hasHorarios && $hasCupof) {
            $res['horarios_fijos'] = castRows($db->query("
                SELECT
                    h.id,
                    h.dia,
                    h.id_horas,
                    h.id_salones,
                    h.cupof,
                    c.id_materias,
                    c.id_cursos,
                    c.turno       AS cupof_turno,
                    m.abreviatura AS materia_abrev,
                    m.nombre      AS materia_nombre,
                    cu.ano        AS curso_ano,
                    cu.division   AS curso_division,
                    CONCAT(cu.ano, 'u00b0 ', cu.division) AS curso_label,
                    CONCAT(s.piso, '-', LPAD(s.numero, 2, '0')) AS aula_codigo,
                    s.numero      AS aula_numero,
                    s.tipo        AS aula_tipo
                FROM horarios h
                JOIN cupof c  ON h.cupof     = c.cupof
                LEFT JOIN materias m   ON c.id_materias = m.id
                LEFT JOIN cursos   cu  ON c.id_cursos   = cu.id
                LEFT JOIN salones  s   ON h.id_salones  = s.id_salones
                ORDER BY h.dia, h.id_horas
            ")->fetchAll());
        }

        ok($res);

    default:
        err('Endpoint not found',404);
}
