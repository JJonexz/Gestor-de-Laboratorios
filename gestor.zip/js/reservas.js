// ============================================================
// reservas.js — Reservas y solicitudes
//
// ¿Qué hay acá?
//   • poblarSelectsReserva()        → llena los <select> del modal
//   • abrirModalReserva/Slot()      → apertura del modal
//   • checkConflict()               → aviso de conflicto en tiempo real
//   • getModulosParaPeriodo()       → expande "turno completo" o multi-hora
//   • guardarReserva()              → lógica de creación (directivo vs profe)
//   • verDetalle()                  → modal de detalle de una reserva
//   • verDetalleSolicitud()         → modal de detalle para el admin
//   • aceptarSolicitud()            → aprueba una solicitud pendiente
//   • rechazarSolicitud()           → rechaza una solicitud pendiente
//
// Depende de: config.js, helpers.js, ui.js, db.js
// ============================================================

// ── Validación de conflictos con horarios académicos (cupof) ──
var HORARIOS_ACADEMICOS = []; // Cachea horarios académicos del sistema
var _cupofsPorProfe = {};     // Cache: dni_personal → array de cupofs del profe

// Carga los cupofs (materias/cursos) activos de un profesor desde la BDD
// Retorna promise con array de { cupof, materia_nombre, materia_abrev, curso_label, curso_ano, division, cupof_turno }
function cargarCupofsPorProfe(dniPersonal) {
  if (!dniPersonal) {
    console.warn('[cupofs] dniPersonal vacío — el profe no tiene dni_personal en gestor_profesores');
    return Promise.resolve([]);
  }
  if (_cupofsPorProfe[dniPersonal]) return Promise.resolve(_cupofsPorProfe[dniPersonal]);
  return apiGet('cupofs-por-profe?dni=' + dniPersonal).then(function(datos) {
    _cupofsPorProfe[dniPersonal] = datos || [];
    console.log('[cupofs] dni=' + dniPersonal + ' → ' + _cupofsPorProfe[dniPersonal].length + ' cupofs cargados', _cupofsPorProfe[dniPersonal]);
    return _cupofsPorProfe[dniPersonal];
  }).catch(function(e) {
    console.warn('[cupofs] Error al cargar cupofs para dni=' + dniPersonal + ':', e);
    _cupofsPorProfe[dniPersonal] = [];
    return [];
  });
}

// Puebla el select #f-cupof con los cupofs del profesor indicado
// Si no tiene cupofs en la BDD, muestra fallback manual
function poblarSelectCupof(dniPersonal, cupofSeleccionado) {
  var sel = document.getElementById('f-cupof');
  var hint = document.getElementById('f-cupof-hint');
  var wrap = document.getElementById('f-cupof-wrap');
  if (!sel) return;

  sel.innerHTML = '<option value="">⌛ Cargando materias…</option>';
  sel.disabled = true;

  cargarCupofsPorProfe(dniPersonal).then(function(cupofs) {
    sel.disabled = false;
    if (!cupofs || cupofs.length === 0) {
      // Sin cupofs en BDD → modo manual: campos desbloqueados
      sel.innerHTML = '<option value="">— Sin carga horaria vinculada —</option>';
      if (hint) hint.style.display = 'block';
      _desbloquearCursoMateria();
  _desbloquearGrupo();
      return;
    }
    if (hint) hint.style.display = 'none';
    var opts = '<option value="">— Seleccioná materia y curso —</option>';
    cupofs.forEach(function(c) {
      var label = (c.materia_nombre || 'Materia ?') + ' — ' + (c.curso_label || '?');
      if (c.cupof_turno) label += ' (' + (c.cupof_turno === 'M' ? 'Mañana' : c.cupof_turno === 'T' ? 'Tarde' : c.cupof_turno === 'V' ? 'Vespertino' : c.cupof_turno) + ')';
      if (c.id_grupos && parseInt(c.id_grupos) > 0) label += ' 👥 Grupo ' + (c.grupo_nombre || c.id_grupos);
      var selected = String(c.cupof) === String(cupofSeleccionado) ? ' selected' : '';
      opts += '<option value="' + c.cupof + '"' + selected +
              ' data-materia="'      + (c.materia_nombre   || '') + '"' +
              ' data-materia-abrev="'+ (c.materia_abrev    || '') + '"' +
              ' data-curso="'        + (c.curso_label      || '') + '"' +
              ' data-curso-ano="'    + (c.curso_ano        || '') + '"' +
              ' data-curso-div="'    + (c.curso_division   || '') + '"' +
              ' data-id-grupos="'    + (c.id_grupos        || 0)  + '"' +
              ' data-grupo-nombre="' + (c.grupo_nombre     || '') + '"' +
              '>' + label + '</option>';
    });
    sel.innerHTML = opts;
    // Si ya había un cupof seleccionado, disparar el change para sincronizar campos
    if (cupofSeleccionado) sincronizarCampoDesdeCupof();
  });
}

// Cuando el usuario elige un cupof, auto-completa Y bloquea curso, materia y grupo
function sincronizarCampoDesdeCupof() {
  var sel = document.getElementById('f-cupof');
  var fCurso   = document.getElementById('f-curso');
  var fMateria = document.getElementById('f-materia');

  if (!sel || !sel.value) {
    _desbloquearCursoMateria();
    _desbloquearGrupo();
    return;
  }

  var opt        = sel.options[sel.selectedIndex];
  var curso      = opt.getAttribute('data-curso')      || '';
  var materia    = opt.getAttribute('data-materia')    || '';
  var idGrupos   = parseInt(opt.getAttribute('data-id-grupos') || '0');
  var grupoNombre= opt.getAttribute('data-grupo-nombre') || '';
  var cursoAno   = opt.getAttribute('data-curso-ano')  || '';

  // Setear curso y materia
  if (fCurso   && curso)   fCurso.value   = curso;
  if (fMateria && materia) fMateria.value = materia;
  _bloquearCursoMateria();

  // Grupo: poblar según curso y luego auto-seleccionar o limpiar
  poblarSelectorGrupo(cursoAno, idGrupos > 0 ? idGrupos : '');

  if (idGrupos > 0) {
    // Taller con grupo fijo → bloquear selector
    _bloquearGrupo(idGrupos, grupoNombre);
  } else {
    // Materia sin grupo → limpiar y desbloquear
    _desbloquearGrupo();
    var selGrupo = document.getElementById('reserva-grupo');
    if (selGrupo) selGrupo.value = '';
  }
}

function _bloquearCursoMateria() {
  var fCurso   = document.getElementById('f-curso');
  var fMateria = document.getElementById('f-materia');
  var row      = document.getElementById('f-curso-materia-row');
  if (fCurso) {
    fCurso.disabled = true;
    fCurso.style.opacity = '0.6';
    fCurso.style.cursor  = 'not-allowed';
    fCurso.title = 'Determinado por el cupof seleccionado';
  }
  if (fMateria) {
    fMateria.readOnly = true;
    fMateria.style.opacity = '0.6';
    fMateria.style.cursor  = 'not-allowed';
    fMateria.title = 'Determinado por el cupof seleccionado';
  }
  // Indicador visual en la fila
  if (row) row.style.opacity = '0.7';
}

function _desbloquearCursoMateria() {
  var fCurso   = document.getElementById('f-curso');
  var fMateria = document.getElementById('f-materia');
  var row      = document.getElementById('f-curso-materia-row');
  if (fCurso) {
    fCurso.disabled = false;
    fCurso.style.opacity = '';
    fCurso.style.cursor  = '';
    fCurso.title = '';
  }
  if (fMateria) {
    fMateria.readOnly = false;
    fMateria.style.opacity = '';
    fMateria.style.cursor  = '';
    fMateria.title = '';
  }
  if (row) row.style.opacity = '';
}

function _bloquearGrupo(idGrupos, grupoNombre) {
  var sel  = document.getElementById('reserva-grupo');
  var wrap = sel ? sel.closest('.form-group') : null;
  if (!sel) return;
  sel.value    = idGrupos;
  sel.disabled = true;
  sel.style.opacity = '0.6';
  sel.style.cursor  = 'not-allowed';
  sel.title = 'Grupo fijo por taller (cupof ' + idGrupos + ')';
  if (wrap) {
    var lbl = wrap.querySelector('label');
    if (lbl && !lbl.querySelector('.grupo-lock-hint')) {
      var hint = document.createElement('small');
      hint.className = 'grupo-lock-hint';
      hint.style.cssText = 'color:var(--navy,#1a3a6b);font-weight:600;margin-left:6px;';
      hint.textContent = '🔒 ' + (grupoNombre ? 'Grupo ' + grupoNombre : 'fijo');
      lbl.appendChild(hint);
    }
  }
}

function _desbloquearGrupo() {
  var sel  = document.getElementById('reserva-grupo');
  var wrap = sel ? sel.closest('.form-group') : null;
  if (!sel) return;
  sel.disabled = false;
  sel.style.opacity = '';
  sel.style.cursor  = '';
  sel.title = '';
  if (wrap) {
    var hint = wrap.querySelector('.grupo-lock-hint');
    if (hint) hint.remove();
  }
}

// Carga horarios académicos del sistema (una sola vez)
function cargarHorariosAcademicos(dniPersonal) {
  if (HORARIOS_ACADEMICOS.length > 0) return Promise.resolve();
  var _dni = dniPersonal || _getDniParaHorarios();
  if (!_dni) return Promise.resolve();
  return apiGet('horarios-academicos?dni=' + _dni).then(function(datos) {
    HORARIOS_ACADEMICOS = datos || [];
    return HORARIOS_ACADEMICOS;
  }).catch(function(e) {
    console.warn('[cargarHorariosAcademicos] Error:', e);
    HORARIOS_ACADEMICOS = [];
    return [];
  });
}

function _getDniParaHorarios() {
  var profeSel = document.getElementById('f-profe');
  var profeId = (typeof esDirectivo === 'function' && esDirectivo() && profeSel && profeSel.value)
    ? parseInt(profeSel.value)
    : (typeof getCurrentProfId === 'function' ? getCurrentProfId() : null);
  var profe = profeId ? getProfe(profeId) : null;
  return profe && profe.dni_personal ? profe.dni_personal : null;
}

// Mapeo: día del gestor (0-4) ↔ día académico (LUN-VIE)
var MAP_DIA_ACADEMICO = {
  0: 'LUN',
  1: 'MAR',
  2: 'MIE',
  3: 'JUE',
  4: 'VIE'
};

// Chequea si hay conflicto entre módulo del gestor y horarios académicos
// Retorna: { hayConflicto: bool, mensaje: string, horasEnConflicto: array }
function chequearConflictoHorarioAcademico(profeId, dia, modulo) {
  if (!profeId || profeId === 'institucional') return { hayConflicto: false };
  
  // Obtener dni_personal del profesor
  var profe = getProfe(profeId);
  if (!profe || !profe.dni_personal) return { hayConflicto: false };
  
  var diaAcademico = MAP_DIA_ACADEMICO[dia] || null;
  if (!diaAcademico) return { hayConflicto: false };
  
  // Convertir módulo del gestor a hora académica (1-13)
  var horaAcademica = moduloAHorarioAcademico(modulo);
  if (horaAcademica === null) return { hayConflicto: false }; // Es un recreo
  
  // Buscar si hay horario académico en ese día y hora
  var horasEnConflicto = HORARIOS_ACADEMICOS.filter(function(h) {
    return h.dia === diaAcademico && h.id_horas === horaAcademica;
  });
  
  if (horasEnConflicto.length > 0) {
    var materias = horasEnConflicto.map(function(h) { return h.materia_nombre || ('Cupof #' + h.cupof); }).join(', ');
    return {
      hayConflicto: true,
      mensaje: 'Conflicto: el profesor tiene clase académica (' + materias + ') en ese horario',
      horasEnConflicto: horasEnConflicto
    };
  }
  
  return { hayConflicto: false };
}

// ── Población de selects del modal ───────────────────────────
function poblarSelectsReserva() {
  // Laboratorios disponibles
  ['f-lab', 'espera-lab'].forEach(function (sid) {
    var sel = document.getElementById(sid);
    if (!sel) return;
    sel.innerHTML =
      '<option value="">Seleccionar laboratorio…</option>' +
      LABS.filter(function (l) { return !l.ocupado; })
        .map(function (l) { return '<option value="' + l.id + '">' + l.nombre + '</option>'; })
        .join('');
  });

  // Días de la semana actual
  ['f-dia', 'espera-dia'].forEach(function (sid) {
    var sel = document.getElementById(sid);
    if (!sel) return;
    sel.innerHTML = '<option value="">Seleccionar día…</option>';
    for (var d = 0; d < 5; d++) {
      var f = getDiaDate(semanaOffset, d);
      sel.innerHTML += '<option value="' + d + '">' + DIAS_SEMANA[d] + ' ' + formatFecha(f) + '</option>';
    }
  });

  // Módulos agrupados por turno
  ['f-modulo', 'espera-modulo'].forEach(function (sid) {
    var sel = document.getElementById(sid);
    if (!sel) return;
    var opts = '<option value="">Seleccionar módulo…</option>';
    var turnoActual = '';
    MODULOS_CLASE.forEach(function (m) {
      if (m.turno !== turnoActual) {
        if (turnoActual) opts += '</optgroup>';
        opts += '<optgroup label="' + m.turno + '">';
        turnoActual = m.turno;
      }
      opts += '<option value="' + m.id + '">' + m.label + ' (' + m.inicio + '–' + m.fin + ')</option>';
    });
    if (turnoActual) opts += '</optgroup>';
    sel.innerHTML = opts;
  });

  // Período de reserva (1h, 2h, 4h, turno completo)
  var fPeriodo = document.getElementById('f-periodo');
  if (fPeriodo) {
    var opts =
      '<option value="1">1 hora (módulo individual)</option>' +
      '<option value="2">2 horas consecutivas</option>' +
      '<option value="4">4 horas consecutivas</option>';
    TURNOS_CONFIG.forEach(function (t) {
      opts += '<option value="turno_' + t.label + '">' + t.icon + ' Turno completo ' + t.label + ' (' + t.modulos.length + ' hs)</option>';
    });
    fPeriodo.innerHTML = opts;
  }

  // Orientaciones (reset)
  UIHelper.setOrientValues('f-orient-group', 'bas');

  // Profesores (solo para directivos)
  ['f-profe', 'edit-profe'].forEach(function (sid) {
    var sel = document.getElementById(sid);
    if (!sel) return;
    var sorted = [].concat(PROFESORES).sort(function (a, b) {
      return a.apellido.localeCompare(b.apellido);
    });
    sel.innerHTML =
      '<option value="">Seleccionar docente…</option>' +
      sorted.map(function (p) {
        return '<option value="' + p.id + '">Prof. ' + p.apellido + ', ' + p.nombre + ' — ' + p.materia + '</option>';
      }).join('');
  });

  // Cursos (master table)
  var fCurso = document.getElementById('f-curso');
  if (fCurso && CURSOS.length > 0) {
    fCurso.innerHTML = '<option value="">Seleccionar curso…</option>' +
      CURSOS.map(function(c) {
        var label = c.ano + '°' + c.division + (c.turno ? ' ('+c.turno+')' : '');
        return '<option value="'+label+'">'+label+'</option>';
      }).join('');
  }

  // Materias (datalist)
  var matList = document.getElementById('materias-list');
  if (matList && MATERIAS.length > 0) {
    matList.innerHTML = MATERIAS.map(function(m) {
      return '<option value="'+m.nombre+'">'+m.abreviatura+'</option>';
    }).join('');
  }
}

// ── Abrir modal (botón "Nueva reserva") ──────────────────────
function abrirModalReserva() {
  poblarSelectsReserva();

  // Limpiar campos y desbloquear curso/materia (por si quedaron bloqueados de antes)
  ['f-lab', 'f-dia', 'f-curso', 'f-materia', 'f-secuencia'].forEach(function (id) {
    var el = document.getElementById(id);
    if (el) el.value = '';
  });
  _desbloquearCursoMateria();
  UIHelper.setOrientValues('f-orient-group', 'bas');
  var fmod = document.getElementById('f-modulo'); if (fmod) fmod.value = '';
  var fper = document.getElementById('f-periodo'); if (fper) fper.value = '1';
  var cw = document.getElementById('conflict-warning'); if (cw) cw.classList.remove('show');

  // Checkbox de reserva anual (solo para directivos)
  var anualWrap = document.getElementById('f-anual-wrap');
  var anualChk = document.getElementById('f-anual');
  if (anualWrap) anualWrap.style.display = esDirectivo() ? 'block' : 'none';
  if (anualChk) anualChk.checked = false;

  // Selector de docente (solo para directivos)
  var profeWrap = document.getElementById('f-profe-wrap');
  var profeSel = document.getElementById('f-profe');
  if (profeWrap) profeWrap.style.display = esDirectivo() ? 'block' : 'none';
  if (profeSel) profeSel.value = '';

  poblarSelectorGrupo('', '');

  var fCursoMain = document.getElementById('f-curso');
  if (fCursoMain && !fCursoMain.dataset.grupoBind) {
    fCursoMain.addEventListener('change', function() {
      poblarSelectorGrupo(this.value, '');
    });
    fCursoMain.dataset.grupoBind = '1';
  }

  // ── Cargar cupofs del profe desde la BDD ────────────────────
  // Para directivos: se carga al elegir docente; por ahora vacío hasta que elijan
  // Para profesores: se carga con el dni propio al instante
  var fCupof = document.getElementById('f-cupof');
  if (fCupof && !fCupof.dataset.cupofBind) {
    fCupof.addEventListener('change', sincronizarCampoDesdeCupof);
    fCupof.dataset.cupofBind = '1';
  }

  if (!esDirectivo()) {
    // Profe: cargar sus propios cupofs
    var profeActual = getProfe(getCurrentProfId());
    var dniActual = profeActual && profeActual.dni_personal ? profeActual.dni_personal : null;
    poblarSelectCupof(dniActual, null);
    cargarHorariosAcademicos(dniActual).catch(function(e) {
      console.warn('No se pudieron cargar horarios académicos:', e);
    });
  } else {
    // Directivo: placeholder vacío hasta que elija docente
    if (fCupof) fCupof.innerHTML = '<option value="">— Primero elegí un docente —</option>';
    // Escuchar cambio de docente
    if (profeSel && !profeSel.dataset.cupofBind) {
      profeSel.addEventListener('change', function() {
        HORARIOS_ACADEMICOS = []; // forzar recarga para el nuevo profe
        var profeElegido = getProfe(parseInt(this.value));
        var dniElegido = profeElegido && profeElegido.dni_personal ? profeElegido.dni_personal : null;
        poblarSelectCupof(dniElegido, null);
        if (dniElegido) cargarHorariosAcademicos(dniElegido).catch(function(){});
      });
      profeSel.dataset.cupofBind = '1';
    }
  }

  abrirModal('modal-reserva');
}

// ── Abrir modal con día/módulo/lab pre-seleccionados ─────────
function abrirModalReservaSlot(dia, modulo, lab) {
  poblarSelectsReserva();

  var fLab = document.getElementById('f-lab');
  var fDia = document.getElementById('f-dia');
  var fMod = document.getElementById('f-modulo');

  if (fLab) fLab.value = lab;
  if (fDia) fDia.value = dia;
  if (fMod) fMod.value = modulo;

  var fCurso = document.getElementById('f-curso');
  var fSeq = document.getElementById('f-secuencia');

  if (fCurso) fCurso.value = '';
  if (fSeq) fSeq.value = '';

  // Inicializar grupos vacío
  poblarSelectorGrupo('', '');

  // IMPORTANTE:
  // actualizar grupos automáticamente cuando cambia el curso
  if (fCurso && !fCurso.dataset.grupoBind) {
    fCurso.addEventListener('change', function() {
      poblarSelectorGrupo(this.value, '');
    });

    // evita múltiples listeners al abrir el modal varias veces
    fCurso.dataset.grupoBind = '1';
  }

  UIHelper.setOrientValues('f-orient-group', 'bas');

  checkConflict();

  // Checkbox reserva anual
  var anualWrap = document.getElementById('f-anual-wrap');
  var anualChk = document.getElementById('f-anual');

  if (anualWrap) anualWrap.style.display = esDirectivo() ? 'block' : 'none';
  if (anualChk) anualChk.checked = false;

  // Selector docente
  var profeWrap = document.getElementById('f-profe-wrap');
  var profeSel = document.getElementById('f-profe');

  if (profeWrap) profeWrap.style.display = esDirectivo() ? 'block' : 'none';
  if (profeSel) profeSel.value = '';

  // ── Cargar cupofs del profe ──────────────────────────────────
  var fCupof = document.getElementById('f-cupof');
  if (fCupof && !fCupof.dataset.cupofBind) {
    fCupof.addEventListener('change', sincronizarCampoDesdeCupof);
    fCupof.dataset.cupofBind = '1';
  }
  if (!esDirectivo()) {
    var profeActual = getProfe(getCurrentProfId());
    var dniActual = profeActual && profeActual.dni_personal ? profeActual.dni_personal : null;
    poblarSelectCupof(dniActual, null);
    cargarHorariosAcademicos(dniActual).catch(function(){});
  } else {
    if (fCupof) fCupof.innerHTML = '<option value="">— Primero elegí un docente —</option>';
    if (profeSel && !profeSel.dataset.cupofBind) {
      profeSel.addEventListener('change', function() {
        HORARIOS_ACADEMICOS = [];
        var profeElegido = getProfe(parseInt(this.value));
        var dniElegido = profeElegido && profeElegido.dni_personal ? profeElegido.dni_personal : null;
        poblarSelectCupof(dniElegido, null);
        if (dniElegido) cargarHorariosAcademicos(dniElegido).catch(function(){});
      });
      profeSel.dataset.cupofBind = '1';
    }
  }

  abrirModal('modal-reserva');
}


// Helper selector grupos
function poblarSelectorGrupo(cursoId, grupoIdActual) {
  const sel = document.getElementById('reserva-grupo');
  if (!sel) return;

  sel.innerHTML = '<option value="">-- Sin grupo --</option>';

  if (!cursoId) return;

  const grupos = getGruposByCurso(cursoId);

  grupos.forEach(g => {
    const opt = document.createElement('option');

    opt.value = g.id;
    opt.textContent = g.nombre;

    if (String(g.id) === String(grupoIdActual)) {
      opt.selected = true;
    }

    sel.appendChild(opt);
  });
}

// ── Verificación de conflicto en tiempo real ─────────────────
function checkConflict() {
  var lab = document.getElementById('f-lab');
  var dia = document.getElementById('f-dia');
  var mod = document.getElementById('f-modulo');
  var cw = document.getElementById('conflict-warning');
  if (!lab || !dia || !mod || !cw) return;
  if (!lab.value || dia.value === '' || mod.value === '') { cw.classList.remove('show'); return; }

  var labData2  = getLab(lab.value);
  var maxG2 = getLabMaxGrupos(lab.value);
  var enSlot2   = RESERVAS.filter(function(r) {
    return r.semanaOffset === semanaOffset
      && r.dia === parseInt(dia.value)
      && r.modulo === parseInt(mod.value)
      && r.lab === lab.value;
  });
  var solConflict = SOLICITUDES.find(function(s) {
    return s.semanaOffset === semanaOffset
      && s.dia === parseInt(dia.value)
      && s.modulo === parseInt(mod.value)
      && s.lab === lab.value
      && s.estado === 'pendiente';
  });
  cw.classList.toggle('show', !!(enSlot2.length >= maxG2 || solConflict));
}

// ── Expande un período a una lista de IDs de módulos ─────────
// periodoVal: '1' | '2' | '4' | 'turno_Mañana' | 'turno_Tarde' | ...
function getModulosParaPeriodo(moduloBase, periodoVal) {
  if (typeof periodoVal === 'string' && periodoVal.indexOf('turno_') === 0) {
    var turnoNombre = periodoVal.replace('turno_', '');
    var tc = TURNOS_CONFIG.find(function (t) { return t.label === turnoNombre; });
    return tc ? tc.modulos : [moduloBase];
  }
  var n = parseInt(periodoVal) || 1;
  if (n === 1) return [moduloBase];
  var idx = MODULOS_CLASE.findIndex(function (m) { return m.id === moduloBase; });
  if (idx < 0) return [moduloBase];
  return MODULOS_CLASE.slice(idx, idx + n).map(function (m) { return m.id; });
}

// (helpers grupo)
function getGrupoById(id) {
  return (window.GRUPOS || []).find(g => String(g.id) === String(id)) || null;
}

function getGruposByCurso(cursoLabel) {
  if (!cursoLabel) return [];
  var curso = (window.CURSOS || []).find(function(c) {
    var label = c.ano + '°' + c.division + (c.turno ? ' (' + c.turno + ')' : '');
    return label === cursoLabel;
  });
  if (!curso) return [];
  return (window.GRUPOS || []).filter(function(g) {
    return String(g.id_cursos) === String(curso.id);
  });
}

function getNombreGrupo(id) {
  const g = getGrupoById(id);
  return g ? String(g.nombre) : '';
}

// ── Guardar reserva ──────────────────────────────────────────
function guardarReserva() {
  var lab = document.getElementById('f-lab').value;
  var dia = document.getElementById('f-dia').value;
  var modulo = document.getElementById('f-modulo').value;
  var curso = document.getElementById('f-curso').value.trim();
  var materia = document.getElementById('f-materia') ? document.getElementById('f-materia').value.trim() : '';
  var secuencia = document.getElementById('f-secuencia').value.trim();
  var orient = UIHelper.getOrientValues('f-orient-group');
 // grupoId eliminado — no depende de BD

  if (materia) secuencia = '[' + materia + '] ' + secuencia;
  var periodoEl = document.getElementById('f-periodo');
  var periodo = periodoEl ? periodoEl.value : '1';

  var anualChk = document.querySelector('#modal-reserva #f-anual');
  var esAnual = esDirectivo() && anualChk !== null && anualChk.checked;

  if (!lab || dia === '' || modulo === '' || !curso || !secuencia) {
    toast('Por favor completá todos los campos.', 'err');
    return;
  }

  var modulosAReservar = getModulosParaPeriodo(parseInt(modulo), periodo);

  // ── CHEQUEO DE CONFLICTOS HORARIOS ACADÉMICOS ─────────────
  var profeId = esDirectivo() && document.getElementById('f-profe').value 
    ? parseInt(document.getElementById('f-profe').value) 
    : getCurrentProfId();
  
  // Cargar horarios académicos si no están cargados
  if (HORARIOS_ACADEMICOS.length === 0) {
    cargarHorariosAcademicos().then(function() {
      // Después de cargar, chequear conflictos
      var conflictoEncontrado = false;
      for (var mi = 0; mi < modulosAReservar.length && !conflictoEncontrado; mi++) {
        var conflicto = chequearConflictoHorarioAcademico(profeId, parseInt(dia), modulosAReservar[mi]);
        if (conflicto.hayConflicto) {
          toast('⚠️ ' + conflicto.mensaje, 'warn');
          console.warn('[guardarReserva] Conflicto horario:', conflicto);
          conflictoEncontrado = true;
        }
      }
      // Continuar guardando (el warning es solo informativo, el profesor puede forzar)
      procederGuardarReserva(lab, dia, modulo, curso, materia, secuencia, orient, periodo, esAnual, semanaOffset, profeId);
    });
    return;
  }
  
  // Si los horarios ya están cargados, chequear de una vez
  for (var mi = 0; mi < modulosAReservar.length; mi++) {
    var conflicto = chequearConflictoHorarioAcademico(profeId, parseInt(dia), modulosAReservar[mi]);
    if (conflicto.hayConflicto) {
      toast('⚠️ ' + conflicto.mensaje, 'warn');
      console.warn('[guardarReserva] Conflicto horario:', conflicto);
    }
  }
  
  procederGuardarReserva(lab, dia, modulo, curso, materia, secuencia, orient, periodo, esAnual, semanaOffset, profeId);
}

// Continúa con la lógica de guardado después del chequeo de conflictos
function procederGuardarReserva(lab, dia, modulo, curso, materia, secuencia, orient, periodo, esAnual, semanaOffset, profeId) {
  var modulosAReservar = getModulosParaPeriodo(parseInt(modulo), periodo);

  // Semanas a cubrir: una sola, o ~40 si es reserva anual
  var semanaBase = parseInt(semanaOffset, 10);
  var semanasAReservar = [semanaBase];
  if (esAnual) {
    semanasAReservar = [];
    for (var sw = semanaBase; sw < semanaBase + 40; sw++) semanasAReservar.push(sw);
  }

  // Validación de conflictos (solo para reserva puntual)
  if (!esAnual) {
    for (var mi = 0; mi < modulosAReservar.length; mi++) {
      var m = modulosAReservar[mi];
      var labData   = getLab(lab);
      var maxGrupos = getLabMaxGrupos(lab);
      var enSlot    = RESERVAS.filter(function(r) {
        return r.semanaOffset === semanaOffset && r.dia === parseInt(dia) && r.modulo === m && r.lab === lab;
      });
      if (enSlot.length >= maxGrupos) {
        toast('El módulo ' + getModulo(m).label + ' ya alcanzó el máximo de ' + maxGrupos + ' grupo(s).', 'warn');
        return;
      }
      var solicPendiente = SOLICITUDES.find(function(s) {
        return s.semanaOffset === semanaOffset && s.dia === parseInt(dia) && s.modulo === m && s.lab === lab && s.estado === 'pendiente';
      });
      if (solicPendiente) { toast('El módulo ' + getModulo(m).label + ' ya tiene solicitud pendiente.', 'warn'); return; }
    }
  }

  if (esDirectivo()) {
    // Directivo: crea reservas directamente (omite slots ya ocupados en modo anual)
    var totalCreadas = 0;
    semanasAReservar.forEach(function (sem) {
      modulosAReservar.forEach(function (m) {
        var yaExiste = RESERVAS.find(function (r) {
          return r.semanaOffset === sem && r.dia === parseInt(dia) && r.modulo === m && r.lab === lab;
        });
        if (yaExiste) return;
        nextId++;
        RESERVAS.push({
          id: nextId,
          semanaOffset: parseInt(sem, 10),
          dia: parseInt(dia, 10),
          modulo: m,
          lab: lab,
          curso: curso,
          orient: orient,
          profeId: esAnual ? 'institucional' : (esDirectivo() && document.getElementById('f-profe').value ? parseInt(document.getElementById('f-profe').value) : getCurrentProfId()),
          secuencia: secuencia,
          cicloClases: 1,
          renovaciones: 0,
          anual: esAnual,
          // (línea eliminada — no enviar grupoId a la API)
        });
        totalCreadas++;
      });
    });

    try {
      saveDB();
    } catch (e) {
      toast('Error al guardar: almacenamiento lleno. Intentá exportar y limpiar la BD.', 'err');
      console.error('[guardarReserva] saveDB falló:', e);
      return;
    }

    cerrarModal('modal-reserva');
    toast(
      esAnual
        ? 'Reserva anual creada: ' + totalCreadas + ' entradas para ~40 semanas.'
        : 'Reserva creada (' + totalCreadas + ' módulo' + (totalCreadas > 1 ? 's' : '') + ').',
      'ok'
    );

  } else {
    // Profesor: crea solicitudes pendientes de aprobación
    modulosAReservar.forEach(function (m) {
      nextId++;
      SOLICITUDES.push({
        id: nextId,
        semanaOffset: semanaOffset,
        dia: parseInt(dia),
        modulo: m,
        lab: lab,
        curso: curso,
        orient: orient,
        profeId: getCurrentProfId(),
        secuencia: secuencia,
        cicloClases: 1,
        estado: 'pendiente',
        esRenovacion: false,
        renovacionNum: 0,
        anual: false,
        grupoId: grupoId,
      });
    });
    cerrarModal('modal-reserva');
    saveDB();
    toast('Solicitud enviada (' + modulosAReservar.length + ' módulo' + (modulosAReservar.length > 1 ? 's' : '') + ').', 'info');
  }

  renderAll();
}

// ── Modal de detalle de reserva ──────────────────────────────
function verDetalle(reservaId) {
  verDetalleGrupo([reservaId]);
}

function verDetalleGrupo(ids) {
  var r = RESERVAS.find(function (x) { return x.id === ids[0]; });
  if (!r) return;

  var modulos = ids.map(function(id) { 
    var res = RESERVAS.find(function(x){ return x.id === id; });
    return res ? res.modulo : r.modulo;
  });

  var p = getProfe(r.profeId);
  var oris = (r.orient || 'bas').split(',');
  var orientBadges = oris.map(function(o) {
    var ori = ORIENTACIONES[o.trim()] || ORIENTACIONES['bas'];
    return '<span class="orient-badge ' + ori.ob + '">' + ori.emoji + ' ' + ori.nombre + '</span>';
  }).join(' ');

  var fecha = getDiaDate(r.semanaOffset, r.dia);
  
  var modInicio = getModulo(Math.min.apply(null, modulos)).inicio;
  var modFin = getModulo(Math.max.apply(null, modulos)).fin;
  var labelModulos = modulos.length > 1 ? modulos.length + ' módulos' : getModulo(r.modulo).label;

  var pct   = (r.cicloClases / 3) * 100;
  var barClass = r.cicloClases >= 3 ? 'full' : (r.cicloClases >= 2 ? 'mid' : 'low');

  var body = document.getElementById('modal-detalle-body');
  if (body) {
    body.innerHTML =
      '<div class="detail-row"><div class="detail-label">Docente</div><div class="detail-value">Prof. ' + p.apellido + ', ' + p.nombre + '</div></div>' +
      '<div class="detail-row"><div class="detail-label">Laboratorio</div><div class="detail-value">' + getLab(r.lab).nombre + '</div></div>' +
      '<div class="detail-row"><div class="detail-label">Fecha / Módulo</div><div class="detail-value">' + DIAS_LARGO[r.dia] + ' ' + formatFecha(fecha) + ' · ' + labelModulos + ' (' + modInicio + '–' + modFin + ')</div></div>' +
      '<div class="detail-row"><div class="detail-label">Curso</div><div class="detail-value">' + r.curso + '</div></div>' +
      (r.grupoId
      ? '<div class="detail-row"><div class="detail-label">Grupo</div><div class="detail-value">Grupo ' + getNombreGrupo(r.grupoId) + '</div></div>'
      : '') +
      '<div class="detail-row"><div class="detail-label">Orientación</div><div class="detail-value"><div class="orient-badge-group">' + orientBadges + '</div></div></div>' +
      '<div class="detail-row"><div class="detail-label">Secuencia</div><div class="detail-value" style="font-style:italic;color:var(--muted);">"' + r.secuencia + '"</div></div>' +
      '<div style="margin-top:14px;">' +
        '<div class="ciclo-bar-label">' +
          '<span style="font-size:12px;font-weight:700;">Ciclo didáctico</span>' +
          '<span style="font-size:11px;color:var(--muted);">Clase ' + r.cicloClases + ' de 3' +
          (r.renovaciones ? '&nbsp;&nbsp;<span style="font-weight:700;color:var(--navy);">Renovación ' + r.renovaciones + '/1</span>' : '') +
          '</span>' +
        '</div>' +
        '<div class="ciclo-bar"><div class="ciclo-bar-fill ' + barClass + '" style="width:' + pct + '%"></div></div>' +
      '</div>';
  }

  var footer = document.getElementById('modal-detalle-footer');
  if (footer) {
    var isOwn = esDirectivo() || r.profeId === getCurrentProfId();
    var renovBtn = '';
    var jsonIds = JSON.stringify(ids);
    if (isOwn && r.cicloClases >= 3 && esDirectivo()) {
      var renov = r.renovaciones || 0;
      renovBtn = renov >= 1
        ? '<button class="btn-ok" onclick=\'cerrarModal("modal-detalle");renovarReservaGrupo(' + jsonIds + ')\'>🔄 Nueva reserva</button>'
        : '<button class="btn-ok" onclick=\'renovarReservaGrupo(' + jsonIds + ');cerrarModal("modal-detalle")\'>↻ Solicitar renovación</button>';
    }
    footer.innerHTML =
      '<button class="btn-cancel" onclick="cerrarModal(\'modal-detalle\')">Cerrar</button>' +
      renovBtn +
      (isOwn ? '<button class="btn-ok" style="background:var(--navy-light);" onclick=\'cerrarModal("modal-detalle");editarReservaGrupo(' + jsonIds + ')\'>✎ Editar</button>' : '') +
      (isOwn ? '<button class="btn-ok" style="background:var(--amber);color:#333;" onclick="cerrarModal(\'modal-detalle\');abrirModalReasignar(' + r.id + ')">🔀 Reasignar</button>' : '') +
      (isOwn ? '<button class="btn-danger" onclick=\'cerrarModal("modal-detalle");cancelarReservaGrupo(' + jsonIds + ')\'>Cancelar reserva</button>' : '');
  }

  abrirModal('modal-detalle');
}

// ── Modal de detalle de solicitud (vista admin) ──────────────
function verDetalleSolicitud(solId) {
  var s = SOLICITUDES.find(function (x) { return x.id === solId; });
  if (!s) return;

  var p = getProfe(s.profeId);
  var oris = (s.orient || 'bas').split(',');
  var orientBadges = oris.map(function(o) {
    var ori = ORIENTACIONES[o.trim()] || ORIENTACIONES['bas'];
    return '<span class="orient-badge ' + ori.ob + '">' + ori.emoji + ' ' + ori.nombre + '</span>';
  }).join(' ');

  var fecha = getDiaDate(s.semanaOffset, s.dia);
  var mod   = getModulo(s.modulo);

  var body = document.getElementById('modal-detalle-body');
  if (body) {
    body.innerHTML =
      '<div class="pending-alert" role="status">⏳ Solicitud pendiente de aprobación</div>' +
      (s.esRenovacion
        ? '<div style="margin-bottom:10px;font-size:13px;">Solicitud de <strong>renovación semana ' + s.renovacionNum + '/1</strong>.</div>'
        : '') +
      '<div class="detail-row"><div class="detail-label">Docente</div><div class="detail-value">Prof. ' + p.apellido + ', ' + p.nombre + '</div></div>' +
      '<div class="detail-row"><div class="detail-label">Laboratorio</div><div class="detail-value">' + getLab(s.lab).nombre + '</div></div>' +
      '<div class="detail-row"><div class="detail-label">Fecha / Módulo</div><div class="detail-value">' + DIAS_LARGO[s.dia] + ' ' + formatFecha(fecha) + ' · ' + mod.label + ' (' + mod.inicio + '–' + mod.fin + ')</div></div>' +
      '<div class="detail-row"><div class="detail-label">Curso</div><div class="detail-value">' + s.curso + '</div></div>' +
      '<div class="detail-row"><div class="detail-label">Orientación</div><div class="detail-value"><div class="orient-badge-group">' + orientBadges + '</div></div></div>' +
      '<div class="detail-row"><div class="detail-label">Secuencia</div><div class="detail-value" style="font-style:italic;color:var(--muted);">"' + s.secuencia + '"</div></div>';
  }

  var footer = document.getElementById('modal-detalle-footer');
  if (footer) {
    footer.innerHTML =
      '<button class="btn-cancel" onclick="cerrarModal(\'modal-detalle\')">Cerrar</button>' +
      '<button class="btn-danger" onclick="cerrarModal(\'modal-detalle\');rechazarSolicitud(' + s.id + ')">✕ Rechazar</button>' +
      '<button class="btn-ok" onclick="cerrarModal(\'modal-detalle\');aceptarSolicitud(' + s.id + ')">✓ Aprobar</button>';
  }

  abrirModal('modal-detalle');
}

// ── Aprobar solicitud ─────────────────────────────────────────
function aceptarSolicitud(solId) {
  if (modoUsuario !== 'admin') { toast('Solo el directivo puede aprobar solicitudes.', 'err'); return; }

  var s = SOLICITUDES.find(function (x) { return x.id === solId; });
  if (!s) return;

  var conflicto = RESERVAS.find(function (r) {
    return r.semanaOffset === s.semanaOffset && r.dia === s.dia && r.modulo === s.modulo && r.lab === s.lab;
  });
  if (conflicto) { toast('Ese turno fue ocupado mientras estaba pendiente.', 'warn'); return; }

  if (s.esRenovacion && s.reservaOriginalId) {
    // Renovación: reiniciar ciclo en la reserva original
    var rOrig = RESERVAS.find(function (x) { return x.id === s.reservaOriginalId; });
    if (rOrig) {
      rOrig.cicloClases = 1;
      rOrig.renovaciones = (rOrig.renovaciones || 0) + 1;
    } else {
      nextId++;
      RESERVAS.push({
        id: nextId, semanaOffset: s.semanaOffset, dia: s.dia, modulo: s.modulo, lab: s.lab,
        curso: s.curso, orient: s.orient, profeId: s.profeId, secuencia: s.secuencia,
        cicloClases: 1, renovaciones: s.renovacionNum || 1,
      });
    }
    SOLICITUDES = SOLICITUDES.filter(function (x) { return x.id !== solId; });
    saveDB();
    toast('Renovación semana ' + s.renovacionNum + '/1 aprobada.', 'ok');
    renderAll();
    return;
  }

  // Solicitud nueva → crear reserva
  // Validar conflicto con nuevo módulo antes de aprobar
  if (typeof validarConflicto === 'function') {
    var conf = validarConflicto(s.lab, s.dia, s.modulo, s.semanaOffset, s.profeId, null);
    if (conf) {
      toast('Conflicto: ' + conf.mensaje, 'err');
      if (typeof mostrarAlertaConflicto === 'function') mostrarAlertaConflicto(conf, s);
      return;
    }
  }
  nextId++;
  var nuevaReserva = {
    id: nextId, semanaOffset: s.semanaOffset, dia: s.dia, modulo: s.modulo, lab: s.lab,
    curso: s.curso, orient: s.orient, profeId: s.profeId, secuencia: s.secuencia,
    cicloClases: 1, renovaciones: 0,
    // (línea eliminada)
  };
  RESERVAS.push(nuevaReserva);
  SOLICITUDES = SOLICITUDES.filter(function (x) { return x.id !== solId; });
  saveDB();
  // Notificar al docente
  if (typeof notifSolicitudAprobada === 'function') notifSolicitudAprobada(s);
  // Emitir sync
  if (typeof emitirSync === 'function') emitirSync('reserva_aprobada', { reservaId: nuevaReserva.id, lab: s.lab });
  toast('Solicitud aprobada. Reserva confirmada.', 'ok');
  renderAll();
}

// ── Rechazar solicitud ────────────────────────────────────────
function rechazarSolicitud(solId) {
  if (modoUsuario !== 'admin') { toast('Solo el directivo puede rechazar solicitudes.', 'err'); return; }

  var s = SOLICITUDES.find(function (x) { return x.id === solId; });
  if (!s) return;

  var p = getProfe(s.profeId);
  confirmar('¿Rechazar la solicitud de <strong>Prof. ' + p.apellido + '</strong> — ' + s.curso + '?', function () {
    SOLICITUDES = SOLICITUDES.filter(function (x) { return x.id !== solId; });
    saveDB();
    if (typeof notifSolicitudRechazada === 'function') notifSolicitudRechazada(s, '');
    if (typeof emitirSync === 'function') emitirSync('solicitud_rechazada', { solicitudId: solId });
    toast('Solicitud rechazada.', 'info');
    renderAll();
  });
}

// ── Aprobar grupo de solicitudes ──────────────────────────────
function aceptarSolicitudGrupo(ids) {
  if (modoUsuario !== 'admin') { toast('Solo el directivo puede aprobar solicitudes.', 'err'); return; }

  // Pre-validar conflictos antes de empezar
  for (var i = 0; i < ids.length; i++) {
    var s = SOLICITUDES.find(function (x) { return x.id === ids[i]; });
    if (!s) continue;
    var conflicto = RESERVAS.find(function (r) {
      return r.semanaOffset === s.semanaOffset && r.dia === s.dia && r.modulo === s.modulo && r.lab === s.lab;
    });
    if (conflicto) {
      toast('El turno del módulo ' + getModulo(s.modulo).label + ' fue ocupado mientras estaba pendiente.', 'warn');
      return;
    }
    if (!s.esRenovacion && typeof validarConflicto === 'function') {
      var conf = validarConflicto(s.lab, s.dia, s.modulo, s.semanaOffset, s.profeId, null);
      if (conf) {
        toast('Conflicto en módulo ' + getModulo(s.modulo).label + ': ' + conf.mensaje, 'err');
        return;
      }
    }
  }

  // Procesar cada solicitud vía API
  var pending = ids.length;
  var processed = 0;
  var firstSol = SOLICITUDES.find(function(x) { return x.id === ids[0]; });

  ids.forEach(function(solId) {
    var s = SOLICITUDES.find(function (x) { return x.id === solId; });
    if (!s) { pending--; return; }

    if (s.esRenovacion && s.reservaOriginalId) {
      var rOrig = RESERVAS.find(function (x) { return x.id === s.reservaOriginalId; });
      if (rOrig) {
        dbEditarReserva(rOrig.id, { cicloClases: 1, renovaciones: (rOrig.renovaciones || 0) + 1 }, function() {
          dbEliminarSolicitud(solId, function() {
            processed++;
            pending--;
            if (pending <= 0) _finalizarAprobacionGrupo(processed, firstSol);
          });
        });
      } else {
        dbCrearReserva({
          semanaOffset: s.semanaOffset, dia: s.dia, modulo: s.modulo, lab: s.lab,
          curso: s.curso, orient: s.orient, profeId: s.profeId, secuencia: s.secuencia,
          cicloClases: 1, renovaciones: s.renovacionNum || 1
        }, function() {
          dbEliminarSolicitud(solId, function() {
            processed++;
            pending--;
            if (pending <= 0) _finalizarAprobacionGrupo(processed, firstSol);
          });
        });
      }
    } else {
      dbCrearReserva({
        semanaOffset: s.semanaOffset, dia: s.dia, modulo: s.modulo, lab: s.lab,
        curso: s.curso, orient: s.orient, profeId: s.profeId, secuencia: s.secuencia,
        cicloClases: 1, renovaciones: 0
      }, function(nuevaReserva) {
        if (typeof emitirSync === 'function') emitirSync('reserva_aprobada', { reservaId: nuevaReserva.id, lab: s.lab });
        dbEliminarSolicitud(solId, function() {
          processed++;
          pending--;
          if (pending <= 0) _finalizarAprobacionGrupo(processed, firstSol);
        });
      });
    }
  });
}

function _finalizarAprobacionGrupo(processed, solicitudRef) {
  if (processed > 0) {
    // Una sola notificación por grupo
    if (solicitudRef && typeof notifSolicitudAprobada === 'function') {
      notifSolicitudAprobada(solicitudRef);
    }
    toast('Solicitudes aprobadas (' + processed + ' módulo/s). Reservas confirmadas.', 'ok');
    renderAll();
  }
}

// ── Rechazar grupo de solicitudes ─────────────────────────────
function rechazarSolicitudGrupo(ids) {
  if (modoUsuario !== 'admin') { toast('Solo el directivo puede rechazar solicitudes.', 'err'); return; }
  
  var primerS = SOLICITUDES.find(function (x) { return x.id === ids[0]; });
  if (!primerS) return;

  var p = getProfe(primerS.profeId);
  confirmar('¿Rechazar la solicitud de <strong>Prof. ' + p.apellido + '</strong> — ' + primerS.curso + ' (' + ids.length + ' módulo/s)?', function () {
    var pending = ids.length;
    ids.forEach(function(solId) {
      dbEliminarSolicitud(solId, function() {
        if (typeof emitirSync === 'function') emitirSync('solicitud_rechazada', { solicitudId: solId });
        pending--;
        if (pending <= 0) {
          // Una sola notificación por grupo
          if (typeof notifSolicitudRechazada === 'function') notifSolicitudRechazada(primerS, '');
          toast('Solicitudes rechazadas.', 'info');
          renderAll();
        }
      });
    });
  });
}

// ── Editar reserva existente ─────────────────────────────────
function editarReserva(reservaId) {
  editarReservaGrupo([reservaId]);
}

function editarReservaGrupo(ids) {
  var r = RESERVAS.find(function (x) { return x.id === ids[0]; });
  if (!r) return;

  var isOwn = esDirectivo() || r.profeId === getCurrentProfId();
  if (!isOwn) { toast('No tenés permiso para editar esta reserva.', 'err'); return; }

  // Llenar los campos del modal de edición
  // Guardamos el JSON de IDs en el campo
  document.getElementById('edit-reserva-id').value = JSON.stringify(ids);
  document.getElementById('edit-curso').value = r.curso;
  document.getElementById('edit-secuencia').value = r.secuencia;
  UIHelper.setOrientValues('edit-orient-group', r.orient);

  // Info de contexto (solo lectura)
  var modulos = ids.map(function(id) { 
    var res = RESERVAS.find(function(x){ return x.id === id; });
    return res ? res.modulo : r.modulo;
  });
  var modInicio = getModulo(Math.min.apply(null, modulos)).inicio;
  var modFin = getModulo(Math.max.apply(null, modulos)).fin;
  var labelModulos = modulos.length > 1 ? modulos.length + ' módulos' : getModulo(r.modulo).label;

  var lab = getLab(r.lab);
  var p = getProfe(r.profeId);
  document.getElementById('edit-info-contexto').innerHTML =
    '<strong>' + lab.nombre + '</strong> · ' + DIAS_LARGO[r.dia] + ' · ' + labelModulos +
    ' (' + modInicio + '–' + modFin + ')' +
    (esDirectivo() ? ' · Prof. ' + p.apellido : '');

  // Selector de docente (solo para directivos)
  poblarSelectsReserva(); // poblar opciones del <select>
  var editProfeWrap = document.getElementById('edit-profe-wrap');
  var editProfeSel = document.getElementById('edit-profe');
  if (editProfeWrap) editProfeWrap.style.display = esDirectivo() ? 'block' : 'none';
  if (editProfeSel) editProfeSel.value = r.profeId;

  // Selector de scope: solo para directivos que editan reservas con ciclo > 1 o anuales
  var scopeWrap = document.getElementById('edit-scope-wrap');
  if (scopeWrap) {
    var showScope = esDirectivo() && (r.anual || r.cicloClases > 1);
    scopeWrap.style.display = showScope ? 'block' : 'none';
    if (showScope) {
      var optSiguientes = document.getElementById('opt-siguientes');
      var optAnual = document.getElementById('opt-anual');
      if (optSiguientes) optSiguientes.style.display = r.anual ? 'none' : 'block';
      if (optAnual) optAnual.style.display = r.anual ? 'block' : 'none';
      var scopeSel = document.getElementById('edit-scope');
      if (scopeSel) scopeSel.value = 'puntual'; // default
    }
  }
  poblarSelectorGrupo(r.curso, r.grupoId || null);

  abrirModal('modal-editar-reserva');
}

// Guarda los cambios del modal de edición.
function guardarEdicionReserva() {
  var idVal = document.getElementById('edit-reserva-id').value;
  var ids = [];
  try { ids = JSON.parse(idVal); } catch(e) { ids = [parseInt(idVal)]; }
  if(!ids.length) return;

  var r = RESERVAS.find(function (x) { return x.id === ids[0]; });
  if (!r) return;

  var nuevoCurso = document.getElementById('edit-curso').value.trim();
  var nuevaSecuencia = document.getElementById('edit-secuencia').value.trim();
  var nuevaOrient = UIHelper.getOrientValues('edit-orient-group');
  var scopeSel = document.getElementById('edit-scope');
  var scope = scopeSel ? scopeSel.value : 'puntual';
  var editGrupoEl = document.getElementById('reserva-grupo');
  var nuevoGrupoId = editGrupoEl && editGrupoEl.value !== '' ? parseInt(editGrupoEl.value) : null;

  // Docente asignado (solo directivos pueden cambiarlo)
  var editProfeSel = document.getElementById('edit-profe');
  var nuevoProfeId = (esDirectivo() && editProfeSel && editProfeSel.value)
    ? parseInt(editProfeSel.value)
    : null;

  if (!nuevoCurso || !nuevaSecuencia) {
    toast('Completá el curso y la secuencia.', 'err');
    return;
  }

  var cursoOriginal = r.curso;
  var profeIdOriginal = r.profeId;

  if (scope === 'anual' && esDirectivo()) {
    var actualizadas = 0;
    RESERVAS.forEach(function (x) {
      if (
        x.lab === r.lab &&
        x.dia === r.dia &&
        x.profeId === profeIdOriginal &&
        x.curso === cursoOriginal &&
        x.anual === true
      ) {
        x.curso = nuevoCurso;
        x.secuencia = nuevaSecuencia;
        x.orient = nuevaOrient;
        if (nuevoProfeId) x.profeId = nuevoProfeId;
        actualizadas++;
      }
    });
    saveDB();
    cerrarModal('modal-editar-reserva');
    toast(actualizadas + ' reserva(s) anual(es) actualizada(s).', 'ok');
  } else if (scope === 'siguientes' && esDirectivo()) {
    var actualizadas = 0;
    RESERVAS.forEach(function (x) {
      if (
        x.lab === r.lab &&
        x.dia === r.dia &&
        x.profeId === profeIdOriginal &&
        x.curso === cursoOriginal &&
        x.semanaOffset >= r.semanaOffset
      ) {
        x.curso = nuevoCurso;
        x.secuencia = nuevaSecuencia;
        x.orient = nuevaOrient;
        if (nuevoProfeId) x.profeId = nuevoProfeId;
        x.grupoId = nuevoGrupoId;
        actualizadas++;
      }
    });
    saveDB();
    cerrarModal('modal-editar-reserva');
    toast(actualizadas + ' reserva(s) actualizada(s).', 'ok');
  } else {
    // Puntual: actualiza todas las horas del mismo bloque en esta semana
    var actualizadas = 0;
    RESERVAS.forEach(function (x) {
      if (
        x.semanaOffset === r.semanaOffset &&
        x.dia === r.dia &&
        x.lab === r.lab &&
        x.profeId === profeIdOriginal &&
        x.curso === cursoOriginal
      ) {
        x.curso = nuevoCurso;
        x.secuencia = nuevaSecuencia;
        x.orient = nuevaOrient;
        if (nuevoProfeId) x.profeId = nuevoProfeId;
        x.grupoId = nuevoGrupoId;
        actualizadas++;
      }
    });
    saveDB();
    cerrarModal('modal-editar-reserva');
    toast(actualizadas + ' módulo(s) actualizado(s).', 'ok');
  }

  renderAll();
}

// ============================================================
// REASIGNAR AULA — Mover reservas de un lab a otro
// ============================================================

// Abre el modal de reasignación desde el detalle de una reserva
function abrirModalReasignar(reservaId) {
  var r = RESERVAS.find(function (x) { return x.id === reservaId; });
  if (!r) return;

  var isOwn = esDirectivo() || r.profeId === getCurrentProfId();
  if (!isOwn) { toast('No tenés permiso para reasignar esta reserva.', 'err'); return; }

  // Guardar ID
  document.getElementById('reasignar-reserva-id').value = reservaId;

  // Info de contexto
  var mod = getModulo(r.modulo);
  var lab = getLab(r.lab);
  var p = getProfe(r.profeId);
  document.getElementById('reasignar-info').innerHTML =
    '<strong>' + r.curso + '</strong> · ' + lab.nombre +
    ' · ' + DIAS_LARGO[r.dia] + ' ' + mod.label +
    ' (' + mod.inicio + '–' + mod.fin + ')' +
    (esDirectivo() ? ' · Prof. ' + p.apellido : '');

  // Poblar selector de labs (excluyendo el actual y los que están en mantenimiento)
  var selLab = document.getElementById('reasignar-lab');
  if (selLab) {
    selLab.innerHTML = '<option value="">Seleccionar nuevo laboratorio…</option>' +
      LABS.filter(function (l) { return l.id !== r.lab && !l.ocupado; }).map(function (l) {
        return '<option value="' + l.id + '">' + l.nombre + '</option>';
      }).join('');
  }

  // Mostrar opción anual si corresponde
  var optAnual = document.getElementById('reasignar-opt-anual');
  if (optAnual) optAnual.style.display = r.anual ? 'block' : 'none';

  // Reset scope
  var scopeSel = document.getElementById('reasignar-scope');
  if (scopeSel) scopeSel.value = 'una';

  // Limpiar conflictos
  var confEl = document.getElementById('reasignar-conflictos');
  if (confEl) confEl.style.display = 'none';

  // Listener para chequear conflictos al cambiar lab o scope
  if (selLab) selLab.onchange = function () { checkConflictosReasignacion(r); };
  if (scopeSel) scopeSel.onchange = function () { checkConflictosReasignacion(r); };

  abrirModal('modal-reasignar');
}

// Chequea si hay conflictos con el lab destino
function checkConflictosReasignacion(r) {
  var nuevoLab = document.getElementById('reasignar-lab').value;
  var scope = document.getElementById('reasignar-scope').value;
  var confEl = document.getElementById('reasignar-conflictos');
  var btnOk = document.getElementById('reasignar-btn-ok');
  if (!nuevoLab || !confEl) { if (confEl) confEl.style.display = 'none'; return; }

  // Buscar las reservas que se moverían
  var aReasignar = obtenerReservasParaReasignar(r, scope);

  // Buscar conflictos en el lab destino
  var conflictos = [];
  aReasignar.forEach(function (res) {
    var existente = RESERVAS.find(function (x) {
      return x.semanaOffset === res.semanaOffset &&
        x.dia === res.dia &&
        x.modulo === res.modulo &&
        x.lab === nuevoLab;
    });
    if (existente) {
      var mod = getModulo(res.modulo);
      conflictos.push(DIAS_SEMANA[res.dia] + ' ' + mod.label);
    }
  });

  if (conflictos.length) {
    confEl.style.display = 'block';
    confEl.innerHTML = '⚠️ <strong>' + conflictos.length + ' conflicto(s)</strong> en ' +
      getLab(nuevoLab).nombre + ': ' + conflictos.slice(0, 5).join(', ') +
      (conflictos.length > 5 ? ' y ' + (conflictos.length - 5) + ' más…' : '') +
      '<br><small>Esas horas se omitirán en la reasignación.</small>';
    if (conflictos.length >= aReasignar.length) {
      btnOk.disabled = true;
      confEl.innerHTML += '<br><strong>No hay horas disponibles para reasignar.</strong>';
    } else {
      btnOk.disabled = false;
    }
  } else {
    confEl.style.display = 'none';
    btnOk.disabled = false;
  }
}

// Obtiene las reservas afectadas según el scope
function obtenerReservasParaReasignar(r, scope) {
  if (scope === 'una') {
    return [r];
  } else if (scope === 'dia') {
    // Todas las horas de este curso en el mismo día/semana/lab/profe
    return RESERVAS.filter(function (x) {
      return x.semanaOffset === r.semanaOffset &&
        x.dia === r.dia &&
        x.lab === r.lab &&
        x.curso === r.curso &&
        x.profeId === r.profeId;
    });
  } else if (scope === 'anual') {
    // Toda la serie anual del mismo curso/día/lab/profe
    return RESERVAS.filter(function (x) {
      return x.lab === r.lab &&
        x.dia === r.dia &&
        x.curso === r.curso &&
        x.profeId === r.profeId &&
        x.anual === true;
    });
  }
  return [r];
}

// ── Mover reserva por drag & drop ────────────────────────────
// Mueve una reserva a un nuevo día/módulo/lab conservando todos sus datos.
// Solo el dueño o un directivo pueden mover la reserva.
function moverReservaASlot(reservaId, nuevoDia, nuevoModulo, nuevoLab) {
  var r = RESERVAS.find(function(x) { return x.id === reservaId; });
  if (!r) { toast('No se encontró la reserva.', 'err'); return; }

  var isOwn = esDirectivo() || r.profeId === getCurrentProfId();
  if (!isOwn) { toast('No tenés permiso para mover esta reserva.', 'err'); return; }

  // Mismo slot: no hacer nada
  if (r.dia === nuevoDia && r.modulo === nuevoModulo && r.lab === nuevoLab) return;

  // Verificar que el destino tenga espacio (máx. grupos)
  var maxG = getLabMaxGrupos(nuevoLab);
  var enSlot = RESERVAS.filter(function(x) {
    return x.semanaOffset === semanaOffset &&
      x.dia === nuevoDia &&
      x.modulo === nuevoModulo &&
      x.lab === nuevoLab &&
      x.id !== reservaId;
  });
  if (enSlot.length >= maxG) { toast('Ese horario ya alcanzó el máximo de ' + maxG + ' grupo(s).', 'warn'); return; }

  var solicPendiente = SOLICITUDES.find(function(s) {
    return s.semanaOffset === semanaOffset &&
      s.dia === nuevoDia &&
      s.modulo === nuevoModulo &&
      s.lab === nuevoLab &&
      s.estado === 'pendiente';
  });
  if (solicPendiente) { toast('Ese horario tiene una solicitud pendiente.', 'warn'); return; }

  // Descripción del movimiento para confirmación
  var modOrig  = getModulo(r.modulo);
  var modDest  = getModulo(nuevoModulo);
  var labOrig  = getLab(r.lab);
  var labDest  = getLab(nuevoLab);

  var desdeStr = DIAS_SEMANA[r.dia]   + ' · ' + modOrig.label + ' (' + modOrig.inicio + '–' + modOrig.fin + ')' + (r.lab !== nuevoLab ? ' · ' + labOrig.nombre : '');
  var hastaStr = DIAS_SEMANA[nuevoDia] + ' · ' + modDest.label + ' (' + modDest.inicio + '–' + modDest.fin + ')' + (r.lab !== nuevoLab ? ' · ' + labDest.nombre : '');

  confirmar(
    '¿Mover <strong>' + r.curso + '</strong>?<br>' +
    '<small style="color:var(--muted)">De: ' + desdeStr + '</small><br>' +
    '<small style="color:var(--muted)">A:&nbsp;&nbsp; ' + hastaStr + '</small>',
    function() {
      // Guardar valores originales por si falla la API
      var diaOriginal    = r.dia;
      var moduloOriginal = r.modulo;
      var labOriginal    = r.lab;

      // Actualizar en memoria primero (respuesta optimista)
      r.dia    = nuevoDia;
      r.modulo = nuevoModulo;
      r.lab    = nuevoLab;
      renderAll();

      // Persistir en la base de datos via API
      fetch('api.php/reservas/' + r.id, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          semanaOffset: r.semanaOffset,
          dia:          nuevoDia,
          modulo:       nuevoModulo,
          lab:          nuevoLab,
          curso:        r.curso,
          orient:       r.orient    || 'bas',
          profeId:      r.profeId,
          secuencia:    r.secuencia || '',
          cicloClases:  r.cicloClases  || 1,
          renovaciones: r.renovaciones || 0,
          anual:        r.anual ? 1 : 0,
          grupoId:      r.grupoId || null
        })
      })
      .then(function(res) { return res.json(); })
      .then(function(data) {
        if (data && data.ok) {
          saveDB();
          toast('Reserva movida a ' + hastaStr + '.', 'ok');
        } else {
          // Revertir si la API devolvió error
          r.dia    = diaOriginal;
          r.modulo = moduloOriginal;
          r.lab    = labOriginal;
          renderAll();
          toast('Error al guardar en la base de datos: ' + (data.error || 'Error desconocido'), 'err');
        }
      })
      .catch(function(err) {
        // Revertir si falló la conexión
        r.dia    = diaOriginal;
        r.modulo = moduloOriginal;
        r.lab    = labOriginal;
        renderAll();
        toast('No se pudo conectar con el servidor.', 'err');
        console.error('[moverReservaASlot] fetch error:', err);
      });
    }
  );
}

// Ejecuta la reasignación
function ejecutarReasignacion() {
  var reservaId = parseInt(document.getElementById('reasignar-reserva-id').value);
  var r = RESERVAS.find(function (x) { return x.id === reservaId; });
  if (!r) return;

  var nuevoLab = document.getElementById('reasignar-lab').value;
  var scope = document.getElementById('reasignar-scope').value;

  if (!nuevoLab) { toast('Seleccioná un laboratorio destino.', 'err'); return; }

  var labDestino = getLab(nuevoLab);
  var labOrigen = getLab(r.lab);
  var aReasignar = obtenerReservasParaReasignar(r, scope);

  var movidas = 0;
  var omitidas = 0;

  aReasignar.forEach(function (res) {
    // Verificar que no haya conflicto en el destino
    var existente = RESERVAS.find(function (x) {
      return x.semanaOffset === res.semanaOffset &&
        x.dia === res.dia &&
        x.modulo === res.modulo &&
        x.lab === nuevoLab;
    });
    if (existente) {
      omitidas++;
      return;
    }
    res.lab = nuevoLab;
    movidas++;
  });

  if (movidas === 0) {
    toast('No se pudo reasignar: todos los horarios están ocupados en ' + labDestino.nombre + '.', 'warn');
    return;
  }

  saveDB();
  cerrarModal('modal-reasignar');

  var msg = movidas + ' hora(s) reasignada(s) de ' + labOrigen.nombre + ' → ' + labDestino.nombre + '.';
  if (omitidas) msg += ' (' + omitidas + ' omitida(s) por conflicto)';
  toast(msg, 'ok');
  renderAll();
}
